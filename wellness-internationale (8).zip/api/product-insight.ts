import { GoogleGenAI } from '@google/genai';
import { rawProductData } from '../lib/product-definitions.ts';
import { translations } from '../lib/translations.ts';
import type { TranslationKey } from '../lib/translations.ts';

export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405, headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { product: clientProduct, context } = await req.json();

    if (!clientProduct || !clientProduct.name || !context) {
        return new Response(JSON.stringify({ error: 'Missing product name or context in request body.' }), {
            status: 400, headers: { 'Content-Type': 'application/json' }
        });
    }
    
    // Find the product from the secure server-side source of truth
    const product = rawProductData.find(p => {
        const nameFR = translations.fr[p.nameKey];
        const nameEN = translations.en[p.nameKey];
        return nameFR === clientProduct.name || nameEN === clientProduct.name;
    });
    
    if(!product) {
       return new Response(JSON.stringify({ error: 'Product not found.' }), {
            status: 404, headers: { 'Content-Type': 'application/json' }
        });
    }


    if (!process.env.API_KEY) {
      console.error("API_KEY environment variable is not set.");
      return new Response(JSON.stringify({ error: 'Server configuration error.' }), {
        status: 500, headers: { 'Content-Type': 'application/json' }
      });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `
        You are a helpful and persuasive sales assistant for 'Wellness Internationale'.
        A customer is looking at the product with name key "${product.nameKey}".
        Product details:
        - Type: ${product.typeKey} - Capacity: ${product.capacityKey} - Key Features: ${product.featureKeys.join(', ')} - Description: ${product.descriptionKey}
        Customer context: ${context}
        Based on everything, generate a single, concise, and compelling sentence (max 25 words) explaining why this product is an excellent choice for them.
        The output should be in the same language as the customer context.
        Start with a phrase like 'A great choice if...' or 'Perfect for...'.
        Focus on a key benefit that distinguishes it, especially considering the comparison context if available.
        Do not use markdown. Return ONLY the sentence.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });

    return new Response(JSON.stringify({ insight: response.text.trim() }), {
      status: 200, headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Product Insight API error:', error);
    const errorMessage = 'Failed to generate AI insight.';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500, headers: { 'Content-Type': 'application/json' }
    });
  }
}