
// This file acts as a serverless function for handling user authentication.

export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405, headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return new Response(JSON.stringify({ error: 'Email and password are required.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }

    // This is a mock authentication. In a real app, you'd check credentials against a database.
    console.log(`Login attempt for email: ${email}`);

    // Simulate a network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simulate a successful login
    return new Response(JSON.stringify({ 
        success: true,
        user: { name: "Demo User", email: email },
        token: "mock-jwt-token" // In a real app, this would be a real JWT
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Login API error:', error);
    return new Response(JSON.stringify({ error: 'An unexpected error occurred.' }), {
      status: 500, headers: { 'Content-Type': 'application/json' }
    });
  }
}
