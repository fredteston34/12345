
import { getBlogPosts, BlogPost } from '../lib/blog-posts.ts';
import { getFaqData, getTestimonialsData, getTimelineData, FaqItem, TestimonialItem, TimelineItem } from '../lib/content-data.ts';
import { translations, TranslationKey } from '../lib/translations.ts';

export const config = {
  runtime: 'edge',
};

// This function simulates a call to a Headless CMS.
export default async function handler(req: Request) {
    const url = new URL(req.url);
    const type = url.searchParams.get('type');
    const lang = url.searchParams.get('lang') === 'en' ? 'en' : 'fr';

    const t = (key: TranslationKey, ...args: (string | number)[]): string => {
        let translation = translations[lang][key] || translations['en'][key] || key;
        if (args.length > 0) {
            args.forEach((arg, index) => {
                translation = translation.replace(`{${index}}`, String(arg));
            });
        }
        return translation;
    };

    let data: BlogPost[] | FaqItem[] | TestimonialItem[] | TimelineItem[];

    switch (type) {
        case 'blog':
            data = getBlogPosts(t);
            break;
        case 'faq':
            data = getFaqData(t);
            break;
        case 'testimonials':
            data = getTestimonialsData(t);
            break;
        case 'timeline':
            data = getTimelineData(t);
            break;
        default:
            return new Response(JSON.stringify({ error: 'Invalid content type' }), {
                status: 400, headers: { 'Content-Type': 'application/json' }
            });
    }

    return new Response(JSON.stringify(data), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Cache-Control': 's-maxage=60, stale-while-revalidate' // Cache content for 1 minute
        },
    });
}
