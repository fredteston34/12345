import { GoogleGenAI, Type } from '@google/genai';
import { rawProductData } from '../lib/product-definitions.ts';

export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405, headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { 
        postalCode, 
        householdSize, 
        bottlesPerWeek, 
        costPerBottle, 
        annualSavings, 
        estimatedGeneratorAnnualCost
    } = await req.json();

    if (!process.env.API_KEY) {
      console.error("API_KEY environment variable is not set.");
      return new Response(JSON.stringify({ error: 'Server configuration error.' }), {
        status: 500, headers: { 'Content-Type': 'application/json' }
      });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // Mock local data based on postal code
    const getLocalData = (code: string) => {
        const firstTwoDigits = parseInt(code.substring(0, 2), 10);
        const humidity = firstTwoDigits > 50 ? 65 : 55; // %
        const electricityCost = firstTwoDigits < 50 ? 0.25 : 0.22; // €/kWh
        return { humidity, electricityCost };
    };
    const localData = getLocalData(postalCode);

    const productInfoForAI = rawProductData.map((p) => 
        `{id: "${p.id}", type: "${p.typeKey}", capacityLiters: ${p.capacityLiters}, description: "${p.descriptionKey}"}`
    ).join(', ');

    const prompt = `
        A user wants a personalized recommendation for an atmospheric water generator. The final output must be in French.
        User's data:
        - Postal Code: ${postalCode} (France)
        - Household Size: ${householdSize} people
        - Weekly consumption of 1.5L bottles: ${bottlesPerWeek}
        - Cost per bottle: €${costPerBottle}

        Contextual data for their location:
        - Average Humidity: ${localData.humidity}%
        - Electricity Cost: €${localData.electricityCost}/kWh

        Available products:
        [${productInfoForAI}]

        Analyze the data. The primary factor for recommendation should be household water needs (assume 2 liters/person/day). The generator capacity must meet this need (${householdSize * 2} liters/day).
        Then, calculate the investment amortization period. Assume device costs (home20: €1500, office100: €4000, industry500: €10000) and an annual operating cost of €${estimatedGeneratorAnnualCost}. The user's annual bottled water spending is €${annualSavings.toFixed(2)}. Amortization in years = (Device Cost) / (Annual Bottled Water Spending - Annual Operating Cost). If savings are less than or equal to operating cost, set it to 99.

        Provide a friendly, encouraging, and personalized message in French. Mention their location (e.g., "dans la région de ${postalCode}").

        Return ONLY the JSON object.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    recommendedProductId: { type: Type.STRING },
                    annualSavings: { type: Type.NUMBER },
                    investmentAmortizationYears: { type: Type.NUMBER },
                    personalizedMessage: { type: Type.STRING }
                },
                required: ["recommendedProductId", "annualSavings", "investmentAmortizationYears", "personalizedMessage"]
            }
        }
    });

    return new Response(response.text, {
      status: 200, headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Savings Analysis API error:', error);
    const errorMessage = 'Failed to get AI analysis.';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500, headers: { 'Content-Type': 'application/json' }
    });
  }
}