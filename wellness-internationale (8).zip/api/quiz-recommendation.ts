import { GoogleGenAI } from '@google/genai';
import { rawProductData } from '../lib/product-definitions.ts';

export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405, headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { answers } = await req.json();

    if (!answers) {
        return new Response(JSON.stringify({ error: 'Missing answers in request body.' }), {
            status: 400, headers: { 'Content-Type': 'application/json' }
        });
    }

    if (!process.env.API_KEY) {
      console.error("API_KEY environment variable is not set.");
      return new Response(JSON.stringify({ error: 'Server configuration error.' }), {
        status: 500, headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const productInfo = rawProductData.map((p) => `ID: ${p.id}, Type: ${p.typeKey}, Description: "${p.descriptionKey}"`).join('; ');
    const prompt = `Based on these user preferences: Use Case - "${answers.q1}", Priority - "${answers.q2}", which of these products is the best fit? Products: [${productInfo}]. Respond with only the product ID of the best match. The translation keys (e.g., 'filter_home') provide context about the product type. The user's answers are in either French or English.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    const recommendedId = response.text.trim();

    return new Response(JSON.stringify({ recommendedId }), {
      status: 200, headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Quiz Recommendation API error:', error);
    const errorMessage = 'Failed to get recommendation.';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500, headers: { 'Content-Type': 'application/json' }
    });
  }
}