// This file acts as a serverless function, typically deployed on platforms like Vercel or Netlify.
// It creates a real backend API endpoint at `/api/contact`.

// Using standard Request/Response objects, which are compatible with modern edge runtimes.
export const config = {
  runtime: 'edge',
};

// A simple email validation helper
const validateEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

// Helper function to simulate sending an email
const sendEmail = async (data: { name: string; email: string; message: string }) => {
  // In a real application, you would integrate with an email service like SendGrid, Resend, or Nodemailer.
  // For this demo, we'll just log to the console and simulate a network delay.
  console.log('--- Sending Email ---');
  console.log(`To: support@wellness-internationale.fr`);
  console.log(`From: ${data.name} <${data.email}>`);
  console.log(`Message: ${data.message}`);
  console.log('---------------------');
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate 1s delay
  // In a real scenario, you'd have error handling for the email service.
  return { success: true };
};


export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  try {
    const { name, email, message } = await req.json();

    // --- Server-side Validation ---
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return new Response(JSON.stringify({ error: 'Name is required.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }
    if (!email || typeof email !== 'string' || !validateEmail(email)) {
      return new Response(JSON.stringify({ error: 'A valid email is required.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return new Response(JSON.stringify({ error: 'Message cannot be empty.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }

    // --- Send Email (Simulated) ---
    const emailResult = await sendEmail({ name, email, message });
    if (!emailResult.success) {
       throw new Error('Failed to send email.');
    }

    // --- Success Response ---
    return new Response(JSON.stringify({ 
        message: `Thank you, ${name}! Your message has been received. We will get back to you at ${email} shortly.` 
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Contact form error:', error);
    let errorMessage = 'An unexpected error occurred.';
    if (error instanceof SyntaxError) {
        errorMessage = 'Invalid request format.';
    }
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
