
// This file acts as a serverless function to simulate placing an order.

export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405, headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { productId } = await req.json();

    if (!productId) {
      return new Response(JSON.stringify({ error: 'Product ID is required.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }

    console.log(`Order placed for filters for product: ${productId}`);
    
    // Simulate a network delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    return new Response(JSON.stringify({ 
        success: true,
        message: `Your filter order has been placed! Order ID: ${Math.random().toString(36).substring(2, 9).toUpperCase()}`
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Order API error:', error);
    return new Response(JSON.stringify({ error: 'An unexpected error occurred while placing your order.' }), {
      status: 500, headers: { 'Content-Type': 'application/json' }
    });
  }
}
