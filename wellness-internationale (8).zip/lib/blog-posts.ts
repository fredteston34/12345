// This file acts as a static data source for blog posts,
// simulating what you might get from a Headless CMS in a real-world scenario.
// Using static content is much better for SEO and performance than generating it on the fly.

import type { TranslationKey } from './translations';

export type BlogPost = {
    title: string;
    description: string;
    content: string;
    date: string;
    imageUrl: string;
};

const placeholderSvg = (text: string) => `data:image/svg+xml,%3Csvg width='800' height='450' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='100%25' height='100%25' fill='%23e2e8f0'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='30' fill='%2394a3b8' text-anchor='middle' dy='.3em'%3E${encodeURIComponent(text)}%3C/text%3E%3C/svg%3E`;

export const getBlogPosts = (t: (key: TranslationKey, ...args: (string | number)[]) => string): BlogPost[] => {
    
    const posts: {
        title: TranslationKey;
        description: TranslationKey;
        content: TranslationKey;
        date: TranslationKey;
        imageUrl: string;
    }[] = [
        {
            title: 'blog_post1_title',
            description: 'blog_post1_desc',
            content: 'blog_post1_content',
            date: 'blog_post1_date',
            imageUrl: placeholderSvg('La Révolution de l\'Hydratation'),
        },
        {
            title: 'blog_post2_title',
            description: 'blog_post2_desc',
            content: 'blog_post2_content',
            date: 'blog_post2_date',
            imageUrl: placeholderSvg('Abandonner l\'Eau en Bouteille'),
        },
        {
            title: 'blog_post3_title',
            description: 'blog_post3_desc',
            content: 'blog_post3_content',
            date: 'blog_post3_date',
            imageUrl: placeholderSvg('Pureté de l\'Eau et Bien-être'),
        }
    ];

    // Map over the keys to get the translated content
    return posts.map(post => ({
        ...post,
        title: t(post.title),
        description: t(post.description),
        content: t(post.content),
        date: t(post.date),
    }));
};