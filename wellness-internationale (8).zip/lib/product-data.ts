// This file enriches the raw product definitions with UI-specific elements
// like translated text and JSX icons.

import React from 'react';
import { Product } from '../types.ts';
import { TranslationKey } from './translations';
import { rawProductData } from './product-definitions.ts';
import { HomeIcon, OfficeIcon, IndustryIcon } from '../components/Icons.tsx';

const getIconForProduct = (productId: string): React.ReactNode => {
    switch (productId) {
        case 'home20':
            return React.createElement(HomeIcon, { className: "w-7 h-7 text-slate-700 dark:text-slate-300" });
        case 'office100':
            return React.createElement(OfficeIcon, { className: "w-7 h-7 text-slate-700 dark:text-slate-300" });
        case 'industry500':
            return React.createElement(IndustryIcon, { className: "w-7 h-7 text-slate-700 dark:text-slate-300" });
        default:
            return null;
    }
};

export const getProductData = (t: (key: TranslationKey, ...args: any[]) => string): Product[] => {
    return rawProductData.map(p => ({
        id: p.id,
        type: t(p.typeKey),
        imageSrc: p.imageSrc,
        srcSet: p.srcSet,
        sizes: p.sizes,
        name: t(p.nameKey),
        capacity: t(p.capacityKey),
        description: t(p.descriptionKey),
        features: p.featureKeys.map(key => t(key)),
        icon: getIconForProduct(p.id)
    }));
};