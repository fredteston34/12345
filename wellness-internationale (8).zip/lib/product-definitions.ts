// This file contains the raw, UI-agnostic product data.
// It uses translation keys and avoids any JSX, making it safe to import in server-side code.

import type { TranslationKey } from './translations';

export interface RawProduct {
    id: string;
    typeKey: TranslationKey;
    imageSrc: string;
    srcSet: string;
    sizes: string;
    nameKey: TranslationKey;
    capacityKey: TranslationKey;
    capacityLiters: number;
    descriptionKey: TranslationKey;
    featureKeys: TranslationKey[];
}

const placeholderSvg = (text: string) => `data:image/svg+xml,%3Csvg width='400' height='300' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='100%25' height='100%25' fill='%23e2e8f0'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='24' fill='%2394a3b8' text-anchor='middle' dy='.3em'%3E${encodeURIComponent(text)}%3C/text%3E%3C/svg%3E`;

export const rawProductData: RawProduct[] = [
    {
        id: 'home20',
        typeKey: 'filter_home',
        imageSrc: placeholderSvg('WI-Home 20'),
        srcSet: '',
        sizes: '',
        nameKey: 'product_home_name',
        capacityKey: 'product_home_capacity',
        capacityLiters: 20,
        descriptionKey: 'product_home_desc',
        featureKeys: ['product_home_feature1', 'product_home_feature2', 'product_home_feature3', 'product_home_feature4'],
    },
    {
        id: 'office100',
        typeKey: 'filter_office',
        imageSrc: placeholderSvg('WI-Office 100'),
        srcSet: '',
        sizes: '',
        nameKey: 'product_office_name',
        capacityKey: 'product_office_capacity',
        capacityLiters: 100,
        descriptionKey: 'product_office_desc',
        featureKeys: ['product_office_feature1', 'product_office_feature2', 'product_office_feature3', 'product_office_feature4'],
    },
    {
        id: 'industry500',
        typeKey: 'filter_industrial',
        imageSrc: placeholderSvg('WI-Industry 500+'),
        srcSet: '',
        sizes: '',
        nameKey: 'product_industrial_name',
        capacityKey: 'product_industrial_capacity',
        capacityLiters: 500,
        descriptionKey: 'product_industrial_desc',
        featureKeys: ['product_industrial_feature1', 'product_industrial_feature2', 'product_industrial_feature3', 'product_industrial_feature4'],
    }
];