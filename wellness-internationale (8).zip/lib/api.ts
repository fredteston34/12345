import type { BlogPost } from './blog-posts.ts';
import type { FaqItem, TestimonialItem, TimelineItem } from './content-data.ts';

type ContentType = 'blog' | 'faq' | 'testimonials' | 'timeline';
// A union type that can represent the data from any of our content endpoints
export type ContentData = BlogPost[] | FaqItem[] | TestimonialItem[] | TimelineItem[];

/**
 * Fetches content from the simulated CMS API.
 * @param type - The type of content to fetch.
 * @param lang - The language for the content.
 * @returns A promise that resolves to the fetched content data.
 * @throws Will throw an error if the network response is not ok.
 */
export const fetchContent = async <T extends ContentData>(type: ContentType, lang: string): Promise<T> => {
    const response = await fetch(`/api/content?type=${type}&lang=${lang}`);
    if (!response.ok) {
        throw new Error(`Failed to fetch ${type}`);
    }
    return response.json() as Promise<T>;
};
