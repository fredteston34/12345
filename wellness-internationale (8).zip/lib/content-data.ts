// This file centralizes static content data, simulating a Headless CMS approach.

import type { TranslationKey } from './translations';

// FAQ Data
export type FaqItem = {
    question: string;
    answer: string;
};

export const getFaqData = (t: (key: TranslationKey) => string): { question: string, answer: string }[] => [
    { question: t('faq1_q'), answer: t('faq1_a') },
    { question: t('faq2_q'), answer: t('faq2_a') },
    { question: t('faq3_q'), answer: t('faq3_a') },
    { question: t('faq4_q'), answer: t('faq4_a') },
    { question: t('faq5_q'), answer: t('faq5_a') }
];

// Testimonials Data
export type TestimonialItem = {
    quote: string;
    name: string;
    location: string;
};

export const getTestimonialsData = (t: (key: TranslationKey) => string): TestimonialItem[] => [
    { quote: t('testimonial1_quote'), name: t('testimonial1_name'), location: t('testimonial1_location') },
    { quote: t('testimonial2_quote'), name: t('testimonial2_name'), location: t('testimonial2_location') },
    { quote: t('testimonial3_quote'), name: t('testimonial3_name'), location: t('testimonial3_location') },
    { quote: t('testimonial4_quote'), name: t('testimonial4_name'), location: t('testimonial4_location') }
];

// Timeline Data
export type TimelineItem = {
    year: string;
    title: string;
    description: string;
};

export const getTimelineData = (t: (key: TranslationKey) => string): TimelineItem[] => [
    { year: t('timeline_item1_year'), title: t('timeline_item1_title'), description: t('timeline_item1_desc') },
    { year: t('timeline_item2_year'), title: t('timeline_item2_title'), description: t('timeline_item2_desc') },
    { year: t('timeline_item3_year'), title: t('timeline_item3_title'), description: t('timeline_item3_desc') },
    { year: t('timeline_item4_year'), title: t('timeline_item4_title'), description: t('timeline_item4_desc') },
    { year: t('timeline_item5_year'), title: t('timeline_item5_title'), description: t('timeline_item5_desc') },
];
