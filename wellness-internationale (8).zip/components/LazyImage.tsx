import React, { useState, useEffect } from 'react';

type LazyImageProps = React.ImgHTMLAttributes<HTMLImageElement> & {
  placeholderSrc: string;
};

const LazyImage: React.FC<LazyImageProps> = ({ placeholderSrc, src, ...props }) => {
  const [imgSrc, setImgSrc] = useState(placeholderSrc);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (src && typeof src === 'string') {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        setImgSrc(src);
        setIsLoaded(true);
      };
    }
  }, [src]);
  
  const customClass = isLoaded ? 'lazy-image-loaded' : 'lazy-image-loading';

  return (
    <img
      {...props}
      src={imgSrc}
      // Add a key to force re-render on src change, ensuring transition always runs
      key={isLoaded ? 'loaded' : 'loading'}
      className={`${props.className || ''} ${customClass}`}
    />
  );
};

export default LazyImage;