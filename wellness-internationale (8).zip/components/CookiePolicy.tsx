import React from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';

const CookiePolicy: React.FC = () => {
    const { t, language } = useTranslations();
    const lastUpdatedDate = new Date().toLocaleDateString(language, { year: 'numeric', month: 'long', day: 'numeric' });

    return (
        <section id="politique-cookies" className="py-20 bg-white dark:bg-slate-900/50 scroll-mt-20">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('cookie_policy_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-3xl mx-auto">
                        {t('cookie_policy_last_updated', lastUpdatedDate)}
                    </p>
                </div>

                <div className="max-w-3xl mx-auto space-y-8 text-slate-700 dark:text-slate-300 leading-relaxed">
                    <div>
                        <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-3">{t('cookie_policy_what_are_cookies_title')}</h3>
                        <p>{t('cookie_policy_what_are_cookies_text')}</p>
                    </div>

                    <div>
                        <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-3">{t('cookie_policy_how_we_use_title')}</h3>
                        <p className="mb-4">{t('cookie_policy_how_we_use_text')}</p>
                        <ul className="list-disc list-inside space-y-2 bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                            <li>
                                <strong>{t('cookie_policy_essential_cookies')}</strong> {t('cookie_policy_essential_cookies_text')}
                            </li>
                            <li>
                                <strong>{t('cookie_policy_analytics_cookies')}</strong> {t('cookie_policy_analytics_cookies_text')}
                            </li>
                             <li>
                                <strong>{t('cookie_policy_marketing_cookies')}</strong> {t('cookie_policy_marketing_cookies_text')}
                            </li>
                        </ul>
                    </div>
                    
                     <div>
                        <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-3">{t('cookie_policy_your_choice_title')}</h3>
                        <p>{t('cookie_policy_your_choice_text')}</p>
                    </div>

                    <div>
                        <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-3">{t('cookie_policy_how_to_manage_title')}</h3>
                        <p>{t('cookie_policy_how_to_manage_text')}</p>
                        <p className="mt-2">
                           {t('cookie_policy_learn_more_cnil_prefix')} <a href="https://www.cnil.fr/fr/cookies-les-outils-pour-les-maitriser" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline dark:text-blue-400">{t('cookie_policy_learn_more_cnil_link_text')}</a>.
                        </p>
                    </div>
                    
                    <div>
                        <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-3">{t('cookie_policy_contact_title')}</h3>
                        <p>
                           {t('cookie_policy_contact_text')} <a href="#contact" className="text-blue-600 hover:underline dark:text-blue-400">{t('cookie_policy_contact_link')}</a>.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default CookiePolicy;