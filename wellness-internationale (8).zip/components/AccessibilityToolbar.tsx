
import React, { useState, useEffect } from 'react';
import { FontSizeIcon, ContrastIcon, LinkIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';

const AccessibilityToolbar: React.FC = () => {
    const { t } = useTranslations();
    const [fontSize, setFontSize] = useState(1);
    const [isHighContrast, setIsHighContrast] = useState(false);
    const [areLinksUnderlined, setAreLinksUnderlined] = useState(false);

    useEffect(() => {
        document.documentElement.style.fontSize = `${fontSize * 16}px`;
    }, [fontSize]);

    useEffect(() => {
        document.documentElement.classList.toggle('high-contrast', isHighContrast);
    }, [isHighContrast]);
    
    useEffect(() => {
        document.documentElement.classList.toggle('underline-links', areLinksUnderlined);
    }, [areLinksUnderlined]);

    const increaseFontSize = () => {
        setFontSize(prev => Math.min(prev + 0.1, 1.5));
    };
    
    const resetFontSize = () => {
        setFontSize(1);
    }

    return (
        <div className="fixed bottom-24 left-8 z-[90] bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-xl shadow-2xl p-3 flex flex-col items-center gap-2">
            <span className="text-sm font-semibold text-slate-700 dark:text-slate-200 sr-only">{t('accessibility_toolbar_title')}</span>
            <button 
                onClick={increaseFontSize}
                onDoubleClick={resetFontSize}
                aria-label={t('accessibility_font_size_increase')}
                className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
                <FontSizeIcon className="w-6 h-6" />
            </button>
            <button 
                onClick={() => setIsHighContrast(prev => !prev)}
                aria-pressed={isHighContrast}
                aria-label={t('accessibility_high_contrast')}
                className={`p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors ${isHighContrast ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
            >
                <ContrastIcon className="w-6 h-6" />
            </button>
            <button 
                onClick={() => setAreLinksUnderlined(prev => !prev)}
                aria-pressed={areLinksUnderlined}
                aria-label={t('accessibility_underline_links')}
                className={`p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors ${areLinksUnderlined ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
            >
                <LinkIcon className="w-6 h-6" />
            </button>
        </div>
    );
};

export default AccessibilityToolbar;