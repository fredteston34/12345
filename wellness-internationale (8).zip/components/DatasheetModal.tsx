
import React from 'react';
import { XIcon, PrinterIcon, CalendarIcon } from './Icons.tsx';
import type { Product } from '../types.ts';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { WaterDropIcon } from './Icons.tsx';
import Modal from './Modal.tsx';

type DatasheetModalProps = {
    product: Product;
    onClose: () => void;
};

const DatasheetModal: React.FC<DatasheetModalProps> = ({ product, onClose }) => {
    const { t } = useTranslations();

    const handlePrint = () => {
        window.print();
    };
    
    const handleCalendarReminder = () => {
        const today = new Date();
        const reminderDate = new Date(today.setMonth(today.getMonth() + 6));
        const startDate = reminderDate.toISOString().replace(/-|:|\.\d\d\d/g,"");
        
        const event = {
            title: t('datasheet_maintenance_event_title', product.name),
            description: t('datasheet_maintenance_event_desc', product.name),
            startDate: startDate,
            endDate: startDate, // For an all-day event
        };

        const googleCalendarUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${event.startDate}/${event.endDate}&details=${encodeURIComponent(event.description)}`;
        
        window.open(googleCalendarUrl, '_blank');
    };

    return (
        <Modal onClose={onClose} panelClassName="max-w-3xl">
            <header className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700 no-print">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{t('datasheet_title')}</h2>
                <div className="flex items-center gap-4">
                    <button onClick={handleCalendarReminder} aria-label={t('datasheet_maintenance_aria', product.name)} className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                        <CalendarIcon className="w-6 h-6" />
                    </button>
                    <button onClick={handlePrint} aria-label={t('datasheet_print_aria')} className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                        <PrinterIcon className="w-6 h-6" />
                    </button>
                    <button onClick={onClose} aria-label={t('compare_modal_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>
            </header>
            
            <div className="overflow-y-auto p-8 printable-content">
                <header className="flex items-center justify-between pb-6 border-b border-slate-200 dark:border-slate-700">
                    <div>
                        <h1 className="text-4xl font-extrabold text-slate-900 dark:text-slate-100">{product.name}</h1>
                        <p className="text-lg text-blue-600 dark:text-blue-400 font-semibold">{product.capacity}</p>
                    </div>
                    <div className="text-right">
                         <a href="#" className="flex items-center space-x-2 justify-end">
                            <WaterDropIcon className="w-8 h-8 text-blue-600 dark:text-blue-500" />
                            <span className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
                                Wellness Internationale
                            </span>
                        </a>
                    </div>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                    <div>
                        <img src={product.imageSrc} alt={product.name} className="w-full h-auto object-cover rounded-lg shadow-lg" />
                    </div>
                    <div>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed mb-6">{product.description}</p>
                        <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200 mb-4 border-b border-slate-200 dark:border-slate-700 pb-2">{t('datasheet_specifications')}</h3>
                        <ul className="space-y-3 text-slate-700 dark:text-slate-300">
                            {product.features.map((feature, index) => (
                                <li key={index} className="flex items-start">
                                    <svg className="w-5 h-5 mr-3 mt-1 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                                    <span>{feature}</span>
                                </li>
                            ))}
                            <li className="flex items-start">
                                <svg className="w-5 h-5 mr-3 mt-1 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                                <span>{t('compare_modal_type')}: {product.type}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default DatasheetModal;
