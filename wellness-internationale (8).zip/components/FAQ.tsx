

import React, { useState } from 'react';
import { ChevronDownIcon, SpinnerIcon, WarningIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import type { FaqItem } from '../lib/content-data.ts';
import { useQuery } from '@tanstack/react-query';
import { fetchContent } from '../lib/api.ts';

const FAQ: React.FC = () => {
    const { t, language } = useTranslations();
    const [activeIndex, setActiveIndex] = useState<number | null>(null);

    const { data: faqData, isLoading, error } = useQuery<FaqItem[], Error>({
        queryKey: ['content', 'faq', language],
        queryFn: () => fetchContent<FaqItem[]>('faq', language),
        initialData: [],
    });

    const toggleFAQ = (index: number) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    return (
        <section id="faq" className="py-20 bg-white dark:bg-slate-900/50" aria-live="polite" aria-busy={isLoading}>
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('faq_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('faq_subtitle')}
                    </p>
                </div>
                <div className="max-w-3xl mx-auto">
                    {isLoading && (
                        <div className="flex justify-center items-center py-10">
                            <SpinnerIcon className="w-10 h-10 text-blue-600 dark:text-blue-500" />
                        </div>
                    )}
                    {error && (
                        <div className="text-center py-10 text-red-500 flex justify-center items-center gap-2">
                            <WarningIcon /> {error.message || 'Could not load FAQs.'}
                        </div>
                    )}
                    {!isLoading && !error && faqData.map((item, index) => (
                        <div key={index} className="border-b border-slate-200 dark:border-slate-700">
                            <button
                                onClick={() => toggleFAQ(index)}
                                className="w-full flex justify-between items-center text-left py-5 px-2 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors rounded-md focus:outline-none focus-visible:bg-slate-100 dark:focus-visible:bg-slate-800 focus-visible:ring-2 focus-visible:ring-blue-500"
                                aria-expanded={activeIndex === index}
                                aria-controls={`faq-answer-${index}`}
                            >
                                <span className="text-lg font-semibold text-slate-800 dark:text-slate-100">{item.question}</span>
                                <ChevronDownIcon className={`w-6 h-6 text-slate-500 transition-transform duration-300 ${activeIndex === index ? 'transform rotate-180' : ''}`} />
                            </button>
                            <div
                                id={`faq-answer-${index}`}
                                role="region"
                                className={`faq-answer ${activeIndex === index ? 'open py-5 px-2' : ''}`}
                            >
                                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{item.answer}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FAQ;