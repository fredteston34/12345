

import React, { useState, useMemo } from 'react';
import { XIcon, PlayIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';

interface Video {
    id: string;
    title: string;
    description: string;
    thumbnail: string;
}

const Videos: React.FC = () => {
    const { t } = useTranslations();
    
    const initialVideoData = useMemo((): Video[] => [
        {
            id: '9bZkp7q19f0',
            title: t('video1_title'),
            description: t('video1_desc'),
            thumbnail: "https://img.youtube.com/vi/9bZkp7q19f0/hqdefault.jpg"
        },
        {
            id: 'JIRPTh90i2M',
            title: t('video2_title'),
            description: t('video2_desc'),
            thumbnail: "https://img.youtube.com/vi/JIRPTh90i2M/hqdefault.jpg"
        },
        {
            id: 'QLg2pko-bE4',
            title: t('video3_title'),
            description: t('video3_desc'),
            thumbnail: "https://img.youtube.com/vi/QLg2pko-bE4/hqdefault.jpg"
        }
    ], [t]);
    
    const [videos, setVideos] = useState<Video[]>(initialVideoData);
    const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
    const [newVideoUrl, setNewVideoUrl] = useState('');
    const [error, setError] = useState('');

    const extractVideoId = (url: string): string | null => {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
        const match = url.match(regex);
        return match ? match[1] : null;
    };

    const handleAddVideo = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const videoId = extractVideoId(newVideoUrl);

        if (videoId) {
            const newVideo: Video = {
                id: videoId,
                title: t('video_user_title'),
                description: newVideoUrl,
                thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
            };
            setVideos(prevVideos => [...prevVideos, newVideo]);
            setNewVideoUrl('');
        } else {
            setError(t('video_invalid_url_error'));
        }
    };

    const openModal = (videoId: string) => {
        setSelectedVideoId(videoId);
    };

    const closeModal = () => {
        setSelectedVideoId(null);
    };

    return (
        <section id="videos" className="py-20 bg-slate-50 dark:bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('videos_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('videos_subtitle')}
                    </p>
                </div>
                
                <div className="max-w-2xl mx-auto mb-12 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
                  <form onSubmit={handleAddVideo} className="flex flex-col sm:flex-row gap-3">
                    <label htmlFor="video-url" className="sr-only">{t('video_add_label')}</label>
                    <input
                      id="video-url"
                      type="url"
                      value={newVideoUrl}
                      onChange={(e) => setNewVideoUrl(e.target.value)}
                      placeholder={t('video_add_placeholder')}
                      aria-label={t('video_add_label')}
                      className="flex-grow block w-full px-4 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-500 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
                    />
                    <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-md transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800">
                      {t('video_add_button')}
                    </button>
                  </form>
                  {error && <p className="text-red-500 dark:text-red-400 text-sm mt-2 text-center">{error}</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {videos.map((video) => (
                        <div
                            key={video.id}
                            className="relative group cursor-pointer rounded-lg overflow-hidden shadow-lg transform hover:-translate-y-2 transition-transform duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 motion-reduce:transform-none"
                            onClick={() => openModal(video.id)}
                            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openModal(video.id); } }}
                            tabIndex={0}
                            role="button"
                            aria-label={t('videos_play_aria', video.title)}
                        >
                            <img src={video.thumbnail} alt={`Miniature for video: ${video.title}`} className="w-full h-56 object-cover" loading="lazy" />
                            <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center items-center transition-opacity duration-300 group-hover:bg-opacity-60">
                                <PlayIcon className="w-16 h-16 text-white opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300" />
                            </div>
                            <div className="absolute bottom-0 left-0 p-4 bg-gradient-to-t from-black/70 to-transparent w-full">
                                <h3 className="text-white text-lg font-bold">{video.title}</h3>
                                <p className="text-slate-200 text-sm truncate">{video.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {selectedVideoId && (
                <Modal onClose={closeModal} panelClassName="!bg-transparent !shadow-none max-w-4xl w-full">
                    <div className="relative w-full">
                        <div className="aspect-video bg-black rounded-lg shadow-2xl">
                            <iframe
                                width="100%"
                                height="100%"
                                src={`https://www.youtube.com/embed/${selectedVideoId}?autoplay=1&rel=0`}
                                title={t('videos_player_title')}
                                frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                                className="rounded-lg"
                            ></iframe>
                        </div>
                        <button onClick={closeModal} aria-label={t('videos_close_aria')} className="absolute -top-4 -right-4 text-white hover:text-slate-300 transition-colors focus:outline-none focus:ring-2 focus:ring-white rounded-full bg-black/50 p-2">
                            <XIcon className="w-8 h-8" />
                        </button>
                    </div>
                </Modal>
            )}
        </section>
    );
};

export default Videos;