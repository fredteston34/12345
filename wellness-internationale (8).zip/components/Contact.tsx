import React, { useState } from 'react';
import { SpinnerIcon, CheckIcon, WarningIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Confetti from './Confetti.tsx';

type FormState = {
    name: string;
    email: string;
    message: string;
};

type TouchedState = {
    name: boolean;
    email: boolean;
    message: boolean;
};

const Contact: React.FC = () => {
    const { t } = useTranslations();
    const [formData, setFormData] = useState<FormState>({ name: '', email: '', message: '' });
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [touched, setTouched] = useState<TouchedState>({ name: false, email: false, message: false });
    const [isLoading, setIsLoading] = useState(false);
    const [showConfetti, setShowConfetti] = useState(false);
    const [submissionResponse, setSubmissionResponse] = useState('');
    const [submissionStatus, setSubmissionStatus] = useState<'idle' | 'success' | 'error'>('idle');

    const validateField = (name: keyof FormState, value: string) => {
        switch (name) {
            case 'name':
                return value.trim() ? '' : t('contact_error_name_required');
            case 'email':
                if (!value.trim()) return t('contact_error_email_required');
                if (!/\S+@\S+\.\S+/.test(value)) return t('contact_error_email_invalid');
                return '';
            case 'message':
                return value.trim() ? '' : t('contact_error_message_required');
            default:
                return '';
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target as { name: keyof FormState, value: string };
        setFormData(prev => ({ ...prev, [name]: value }));
        if (touched[name]) {
            const error = validateField(name, value);
            setErrors(prev => ({ ...prev, [name]: error }));
        }
    };
    
    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target as { name: keyof FormState, value: string };
        setTouched(prev => ({ ...prev, [name]: true }));
        const error = validateField(name, value);
        setErrors(prev => ({ ...prev, [name]: error }));
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const formValidation = Object.keys(formData).reduce((acc, key) => {
            const field = key as keyof FormState;
            const error = validateField(field, formData[field]);
            if (error) {
                acc[field] = error;
            }
            return acc;
        }, {} as { [key: string]: string });
        
        setErrors(formValidation);
        setTouched({ name: true, email: true, message: true });

        if (Object.keys(formValidation).length > 0) {
            return;
        }
        
        setIsLoading(true);
        setSubmissionResponse('');
        setSubmissionStatus('idle');

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || t('contact_error_generic'));
            }
            
            setSubmissionResponse(result.message);
            setSubmissionStatus('success');
            setShowConfetti(true);
            setFormData({ name: '', email: '', message: '' });
            setTouched({ name: false, email: false, message: false });

            setTimeout(() => {
                 setSubmissionStatus('idle');
                 setShowConfetti(false);
            }, 8000);

        } catch (error) {
             console.error("Contact form submission failed:", error);
             const errorMessage = error instanceof Error ? error.message : t('contact_error_generic');
             setSubmissionResponse(errorMessage);
             setSubmissionStatus('error');
             setTimeout(() => {
                setSubmissionStatus('idle');
           }, 8000);
        } finally {
            setIsLoading(false);
        }
    };

    const getInputStatus = (name: keyof FormState) => {
        if (!touched[name]) return 'neutral';
        return errors[name] ? 'error' : 'success';
    };

    const labels = {
        name: t('contact_form_name'),
        email: t('contact_form_email'),
        message: t('contact_form_message'),
    };

    return (
        <section id="contact" className="py-20 bg-slate-100 dark:bg-slate-800">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('contact_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('contact_subtitle')}
                    </p>
                </div>

                <div className="relative max-w-2xl mx-auto bg-white dark:bg-slate-700 p-8 rounded-lg shadow-lg min-h-[500px]">
                    {showConfetti && <Confetti />}
                    {submissionStatus !== 'idle' ? (
                         <div className={`text-center p-4 rounded-lg animate-fade-in ${
                            submissionStatus === 'success' 
                                ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200'
                                : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-200'
                        }`}>
                            <h3 className="font-semibold text-xl mb-2">
                                {submissionStatus === 'success' ? t('contact_success_title') : t('contact_error_title')}
                            </h3>
                            <p>{submissionResponse}</p>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} className="space-y-8" noValidate>
                            {(['name', 'email', 'message'] as Array<keyof FormState>).map((fieldName) => {
                                const status = getInputStatus(fieldName);
                                const isTextarea = fieldName === 'message';
                                const InputComponent = isTextarea ? 'textarea' : 'input';
                                const commonProps = {
                                    id: fieldName,
                                    name: fieldName,
                                    value: formData[fieldName],
                                    onChange: handleChange,
                                    onBlur: handleBlur,
                                    className: `peer block w-full px-3 py-2 bg-transparent border rounded-md shadow-sm placeholder-transparent focus:outline-none focus:ring-1 transition-colors text-slate-900 dark:text-slate-100
                                        ${status === 'error' ? 'border-red-500 focus:ring-red-500' : ''}
                                        ${status === 'success' ? 'border-green-500 focus:ring-green-500' : ''}
                                        ${status === 'neutral' ? 'border-slate-300 dark:border-slate-500 focus:ring-blue-500' : ''}
                                    `,
                                    placeholder: labels[fieldName],
                                    ...(isTextarea && { rows: 4 })
                                };

                                return (
                                    <div key={fieldName} className="relative">
                                        <InputComponent {...commonProps} />
                                        <label
                                            htmlFor={fieldName}
                                            className={`absolute left-2 -top-2.5 bg-white dark:bg-slate-700 px-1 text-sm transition-all duration-200 ease-in-out 
                                                ${status === 'error' ? 'text-red-600' : ''}
                                                ${status === 'success' ? 'text-green-600' : ''}
                                                ${status === 'neutral' ? 'text-slate-500 dark:text-slate-400' : ''}
                                                peer-focus:${status === 'error' ? 'text-red-600' : (status === 'success' ? 'text-green-600' : 'text-blue-600 dark:text-blue-400')}
                                                peer-placeholder-shown:text-base peer-placeholder-shown:text-slate-400 peer-placeholder-shown:top-2.5
                                                peer-focus:-top-2.5 peer-focus:text-sm`}
                                        >
                                            {labels[fieldName]}
                                        </label>
                                        <div className="absolute inset-y-0 right-3 flex items-center">
                                            {status === 'success' && <CheckIcon className="w-5 h-5 text-green-500" />}
                                            {status === 'error' && <WarningIcon className="w-5 h-5 text-red-500" />}
                                        </div>
                                        {errors[fieldName] && touched[fieldName] && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors[fieldName]}</p>}
                                    </div>
                                );
                            })}
                            
                            <div>
                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-700 transition-all duration-300 disabled:bg-blue-400 disabled:cursor-not-allowed active:scale-95 transform"
                                >
                                    {isLoading ? <SpinnerIcon className="w-5 h-5" /> : t('contact_form_submit')}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </section>
    );
};

export default Contact;