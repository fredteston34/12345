
import React from 'react';
import { XIcon, SpinnerIcon, WarningIcon, SparklesIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';

type InsightState = {
    productName: string;
    insight: string;
    isLoading: boolean;
    error: string | null;
};

type InsightModalProps = {
    state: InsightState;
    onClose: () => void;
};

const InsightModal: React.FC<InsightModalProps> = ({ state, onClose }) => {
    const { t } = useTranslations();

    return (
        <Modal onClose={onClose} panelClassName="max-w-lg">
            <header className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <SparklesIcon className="w-6 h-6 text-blue-500"/>
                    {t('product_insight_modal_title', state.productName)}
                </h2>
                <button onClick={onClose} aria-label={t('product_insight_modal_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="flex-grow p-8 flex items-center justify-center text-center min-h-[12rem]">
                {state.isLoading && (
                    <div>
                        <SpinnerIcon className="w-12 h-12 text-blue-500 mx-auto" />
                        <p className="mt-4 text-slate-600 dark:text-slate-300">{t('product_ai_generating')}</p>
                    </div>
                )}
                {state.error && (
                    <div className="p-4 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-lg flex items-center gap-2">
                        <WarningIcon className="w-5 h-5"/>
                        <p>{state.error}</p>
                    </div>
                )}
                {state.insight && (
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/30 border-l-4 border-blue-500 dark:border-blue-400 rounded-r-lg">
                        <p className="text-lg text-slate-700 dark:text-slate-200 italic">"{state.insight}"</p>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default InsightModal;
