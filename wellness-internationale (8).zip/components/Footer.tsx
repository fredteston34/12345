import React from 'react';
import { WaterDropIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';

const Footer: React.FC = () => {
    const { t } = useTranslations();
    
    return (
        <footer className="bg-slate-800 text-slate-300 dark:bg-slate-900">
            <div className="container mx-auto px-6 py-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="md:col-span-1">
                        <a href="#accueil" className="flex items-center space-x-2 mb-4 rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                            <WaterDropIcon className="w-8 h-8 text-blue-400" />
                            <span className="text-xl font-bold text-white tracking-tight">
                                Wellness Internationale
                            </span>
                        </a>
                        <p className="text-slate-400">
                            {t('footer_tagline')}
                        </p>
                    </div>
                    <div className="md:col-span-1">
                        <h4 className="font-semibold text-white mb-4">{t('footer_nav_title')}</h4>
                        <ul className="space-y-2">
                            <li><a href="#fonctionnement" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_hiw')}</a></li>
                            <li><a href="#produits" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_products')}</a></li>
                            <li><a href="#avantages" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_benefits')}</a></li>
                            <li><a href="#blog" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_blog')}</a></li>
                            <li><a href="#contact" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_contact')}</a></li>
                            <li><a href="#politique-cookies" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_cookie')}</a></li>
                        </ul>
                    </div>
                    <div className="md:col-span-1">
                        <h4 className="font-semibold text-white mb-4">{t('footer_contact_title')}</h4>
                        <ul className="space-y-2 text-slate-400">
                          <li>123 Rue de l'Avenir, 75000 Paris, France</li>
                          <li>contact@wellness-internationale.fr</li>
                          <li>+33 1 23 45 67 89</li>
                        </ul>
                    </div>
                </div>

                <div className="mt-12 border-t border-slate-700 pt-8 flex flex-col md:flex-row justify-between items-center">
                    <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4 text-sm text-slate-400">
                        <span>{t('footer_copyright', new Date().getFullYear())}</span>
                        <span className="hidden md:inline">·</span>
                        <a href="#politique-cookies" className="hover:text-blue-400 transition-colors rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">{t('footer_nav_cookie')}</a>
                    </div>
                    <div className="flex space-x-4 mt-4 md:mt-0">
                        <a href="#facebook" aria-label="Facebook" className="text-slate-400 hover:text-white transition-colors rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm3.31 11.4h-2.79v7.1h-3.32v-7.1H8.01v-2.7h1.19V7.9c0-1.07.51-2.7 2.7-2.7h2.11v2.7h-1.4c-.41 0-.71.3-.71.71v1.7h2.11l-.31 2.7z"/></svg>
                        </a>
                        <a href="#linkedin" aria-label="LinkedIn" className="text-slate-400 hover:text-white transition-colors rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h14zm-7 5.07h-2.5v7.86h2.5V8.07zM8.25 6.75a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM16.5 12.02c0-1.3-.8-2.2-1.9-2.2s-1.9.9-1.9 2.2v3.91h-2.5V11c0-2 .9-3.7 3.2-3.7s3.1 1.7 3.1 3.7v4.93h-1.9v-3.91z"/></svg>
                        </a>
                        <a href="#twitter" aria-label="Twitter" className="text-slate-400 hover:text-white transition-colors rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.49-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.76 2.81 1.91 3.58-.7-.02-1.36-.21-1.94-.54v.05c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 01-1.93.07 4.28 4.28 0 004 2.98 8.52 8.52 0 01-5.33 1.84c-.35 0-.69-.02-1.03-.06C3.44 20.29 5.7 21 8.12 21c7.34 0 11.36-6.08 11.36-11.36 0-.17 0-.34-.01-.51.78-.56 1.45-1.26 1.99-2.04z"/></svg>
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;