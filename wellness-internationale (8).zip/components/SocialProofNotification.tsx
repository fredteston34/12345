import React, { useState, useEffect, useMemo } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { SparklesIcon } from './Icons.tsx';

const SocialProofNotification: React.FC = () => {
    const { t } = useTranslations();
    const [isVisible, setIsVisible] = useState(false);
    const [currentMessage, setCurrentMessage] = useState('');
    const [messageKey, setMessageKey] = useState(0);

    const messages = useMemo(() => [
        t('social_proof_1'),
        t('social_proof_2'),
        t('social_proof_3'),
        t('social_proof_4'),
        t('social_proof_5'),
    ], [t]);

    useEffect(() => {
        const showRandomMessage = () => {
            const randomIndex = Math.floor(Math.random() * messages.length);
            setCurrentMessage(messages[randomIndex]);
            setMessageKey(prev => prev + 1); // Force re-render and animation reset
            setIsVisible(true);

            // Hide after animation duration
            setTimeout(() => {
                setIsVisible(false);
            }, 5000); // Must match animation duration in styles.css
        };

        // Start after a delay, then repeat
        const initialTimeout = setTimeout(showRandomMessage, 8000);
        const interval = setInterval(showRandomMessage, 12000);

        return () => {
            clearTimeout(initialTimeout);
            clearInterval(interval);
        };
    }, [messages]);
    
    if (!isVisible) return null;

    return (
        <div key={messageKey} className="fixed bottom-8 left-8 z-[90] animate-slide-in-out">
            <div className="bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-xl shadow-2xl p-4 flex items-start gap-4 max-w-sm">
                <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-full p-2">
                    <SparklesIcon className="w-5 h-5" />
                </div>
                <p 
                    className="text-sm text-slate-700 dark:text-slate-200"
                    dangerouslySetInnerHTML={{ __html: currentMessage }} 
                />
            </div>
        </div>
    );
};

export default SocialProofNotification;
