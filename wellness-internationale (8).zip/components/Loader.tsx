import React from 'react';
import { SpinnerIcon } from './Icons.tsx';

const Loader: React.FC = () => (
    <div className="flex justify-center items-center py-20">
        <SpinnerIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />
    </div>
);

export default Loader;