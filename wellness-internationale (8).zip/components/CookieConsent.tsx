import React, { useState, useEffect } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';

const CookieConsent: React.FC = () => {
    const { t } = useTranslations();
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const consent = localStorage.getItem('cookie_consent');
        if (!consent) {
            const timer = setTimeout(() => {
                setIsVisible(true);
            }, 500);
            return () => clearTimeout(timer);
        }
    }, []);

    const handleConsent = (consent: 'accepted' | 'rejected') => {
        localStorage.setItem('cookie_consent', consent);
        setIsVisible(false);
        if (consent === 'accepted') {
            console.log("Cookie consent accepted. Analytics can be initialized.");
        } else {
            console.log("Cookie consent rejected.");
        }
    };

    if (!isVisible) {
        return null;
    }

    return (
        <div 
            className="fixed bottom-0 inset-x-0 bg-slate-800/95 backdrop-blur-sm text-white dark:bg-slate-900/95 p-5 shadow-2xl z-[100] animate-slide-in-up"
            role="dialog"
            aria-live="polite"
            aria-label={t('cookie_consent_title')}
        >
            <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-5">
                <p className="text-sm text-slate-200 max-w-3xl text-center md:text-left">
                    {t('cookie_consent_text')}
                    {' '}
                    <a href="#politique-cookies" className="underline hover:text-blue-400 transition-colors rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                        {t('cookie_consent_learn_more')}
                    </a>.
                </p>
                <div className="flex-shrink-0 flex items-center gap-3">
                    <button
                        onClick={() => handleConsent('rejected')}
                        className="bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-5 rounded-md transition-colors duration-300 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-800 dark:focus-visible:ring-offset-slate-900 focus-visible:ring-white"
                    >
                        {t('cookie_consent_reject')}
                    </button>
                    <button
                        onClick={() => handleConsent('accepted')}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-md transition-colors duration-300 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-800 dark:focus-visible:ring-offset-slate-900 focus-visible:ring-white"
                    >
                        {t('cookie_consent_accept')}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CookieConsent;