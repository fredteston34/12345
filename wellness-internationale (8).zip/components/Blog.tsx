

import React, { useState, Suspense, lazy } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { CalendarIcon, SpinnerIcon, WarningIcon } from './Icons.tsx';
import { BlogPost } from '../lib/blog-posts.ts';
import { useQuery } from '@tanstack/react-query';
import { fetchContent } from '../lib/api.ts';

const BlogModal = lazy(() => import('./BlogModal.tsx'));

const PostCard: React.FC<{ post: BlogPost; onClick: () => void; isFeatured?: boolean }> = ({ post, onClick, isFeatured }) => {
    const { t } = useTranslations();
    
    if (isFeatured) {
        return (
            <div
                role="button"
                tabIndex={0}
                onClick={onClick}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onClick(); }}
                className="col-span-1 md:col-span-2 bg-white dark:bg-slate-800 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 overflow-hidden flex flex-col md:flex-row"
            >
                <img src={post.imageUrl} alt={post.title} className="w-full md:w-1/2 h-64 md:h-auto object-cover" crossOrigin="anonymous" />
                <div className="p-6 flex flex-col justify-center">
                    <h3 className="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">{post.title}</h3>
                    <p className="flex items-center text-sm text-slate-500 dark:text-slate-400 mb-3">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {post.date}
                    </p>
                    <p className="text-slate-600 dark:text-slate-300 mb-4 flex-grow">{post.description}</p>
                    <span className="text-blue-600 dark:text-blue-400 font-semibold hover:underline mt-auto">
                        {t('blog_read_more')} &rarr;
                    </span>
                </div>
            </div>
        );
    }

    return (
        <div
            role="button"
            tabIndex={0}
            onClick={onClick}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onClick(); }}
            className="bg-white dark:bg-slate-800 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 overflow-hidden"
        >
            <img src={post.imageUrl} alt={post.title} className="w-full h-48 object-cover" crossOrigin="anonymous" />
            <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">{post.title}</h3>
                <p className="flex items-center text-sm text-slate-500 dark:text-slate-400 mb-3">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {post.date}
                </p>
                <p className="text-slate-600 dark:text-slate-300 mb-4 text-sm">{post.description}</p>
                 <span className="text-blue-600 dark:text-blue-400 font-semibold hover:underline text-sm">
                    {t('blog_read_more')} &rarr;
                </span>
            </div>
        </div>
    );
};


const Blog: React.FC = () => {
    const { t, language } = useTranslations();
    const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

    const { data: posts, isLoading, error } = useQuery<BlogPost[], Error>({
        queryKey: ['content', 'blog', language],
        queryFn: () => fetchContent<BlogPost[]>('blog', language),
        // Using initialData to prevent layout shifts and ensure posts is never undefined
        initialData: [],
    });

    const featuredPost = posts[0];
    const otherPosts = posts.slice(1);

    return (
        <>
            <section id="blog" className="py-20 bg-slate-50 dark:bg-slate-900/50" aria-live="polite" aria-busy={isLoading}>
                <div className="container mx-auto px-6">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('blog_title')}</h2>
                        <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                            {t('blog_subtitle')}
                        </p>
                    </div>

                    {isLoading && (
                        <div className="flex justify-center items-center py-20">
                            <SpinnerIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />
                        </div>
                    )}

                    {error && (
                        <div className="text-center py-10 text-red-500 flex justify-center items-center gap-2">
                            <WarningIcon /> {error.message || t('blog_error_fetching')}
                        </div>
                    )}

                    {!isLoading && !error && posts.length === 0 && (
                        <p className="mt-8 text-lg text-center text-slate-600 dark:text-slate-300">{t('blog_no_posts')}</p>
                    )}
                    
                    {!isLoading && !error && posts.length > 0 && (
                        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                           {featuredPost && (
                               <PostCard post={featuredPost} onClick={() => setSelectedPost(featuredPost)} isFeatured />
                           )}
                           {otherPosts.map((post, index) => (
                               <PostCard key={index} post={post} onClick={() => setSelectedPost(post)} />
                           ))}
                        </div>
                    )}
                </div>
            </section>

            <Suspense>
                {selectedPost && <BlogModal post={selectedPost} onClose={() => setSelectedPost(null)} />}
            </Suspense>
        </>
    );
};

export default Blog;