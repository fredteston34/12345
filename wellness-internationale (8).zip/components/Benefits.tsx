import React from 'react';
import { ShieldCheckIcon, LeafIcon, ZapIcon, GlobeIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';

type BenefitItemProps = {
    icon: React.ReactNode;
    title: string;
    description: string;
};

const BenefitItem: React.FC<BenefitItemProps> = ({ icon, title, description }) => (
    <div className="flex items-start space-x-4" aria-label={title}>
        <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-full p-3">
            {icon}
        </div>
        <div>
            <p className="text-slate-600 dark:text-slate-300">{description}</p>
        </div>
    </div>
);

const Benefits: React.FC = () => {
    const { t } = useTranslations();
    
    const benefitsData = [
        {
            icon: <ShieldCheckIcon className="w-7 h-7" />,
            title: t('benefit1_title'),
            description: t('benefit1_desc')
        },
        {
            icon: <LeafIcon className="w-7 h-7" />,
            title: t('benefit2_title'),
            description: t('benefit2_desc')
        },
        {
            icon: <ZapIcon className="w-7 h-7" />,
            title: t('benefit3_title'),
            description: t('benefit3_desc')
        },
        {
            icon: <GlobeIcon className="w-7 h-7" />,
            title: t('benefit4_title'),
            description: t('benefit4_desc')
        }
    ];

    const placeholderImage = `data:image/svg+xml,%3Csvg width='600' height='700' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='100%25' height='100%25' fill='%23e2e8f0'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='40' fill='%2394a3b8' text-anchor='middle' dy='.3em'%3EBenefit Image%3C/text%3E%3C/svg%3E`;

    return (
        <section id="avantages" className="py-20 bg-white dark:bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div className="pr-0 lg:pr-12">
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100 mb-6">
                            {t('benefits_title')}
                        </h2>
                        <p className="text-lg text-slate-600 dark:text-slate-300 mb-8">
                            {t('benefits_subtitle')}
                        </p>
                        <div className="space-y-8">
                            {benefitsData.map((benefit, index) => (
                                <BenefitItem key={index} {...benefit} />
                            ))}
                        </div>
                    </div>
                    <div>
                        <img 
                            src={placeholderImage}
                            alt={t('gallery3_alt')}
                            loading="lazy"
                            className="rounded-xl shadow-2xl dark:shadow-black/30 w-full h-full object-cover"
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Benefits;