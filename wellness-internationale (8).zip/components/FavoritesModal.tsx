
import React from 'react';
import { XIcon } from './Icons.tsx';
import type { Product } from '../types.ts';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';

type FavoritesModalProps = {
    products: Product[];
    onClose: () => void;
    onClear: () => void;
    onRemove: (productName: string) => void;
};

const FavoritesModal: React.FC<FavoritesModalProps> = ({ products, onClose, onClear, onRemove }) => {
    const { t } = useTranslations();
    
    return (
        <Modal onClose={onClose} panelClassName="max-w-lg">
            <header className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{t('favorites_modal_title')}</h2>
                <button onClick={onClose} aria-label={t('favorites_modal_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="overflow-y-auto flex-grow p-6">
                {products.length === 0 ? (
                    <p className="text-slate-600 dark:text-slate-300 text-center py-8">{t('favorites_modal_empty')}</p>
                ) : (
                    <ul className="space-y-4">
                        {products.map(product => (
                            <li key={product.name} className="flex items-center gap-4 bg-slate-50 dark:bg-slate-700 p-3 rounded-lg">
                                <img src={product.imageSrc} alt={product.name} className="w-20 h-20 object-cover rounded-md flex-shrink-0" />
                                <div className="flex-grow">
                                    <h3 className="font-bold text-slate-800 dark:text-slate-100">{product.name}</h3>
                                    <p className="text-sm text-slate-500 dark:text-slate-400">{product.capacity}</p>
                                </div>
                                <button
                                    onClick={() => onRemove(product.name)}
                                    aria-label={t('favorites_modal_remove_aria', product.name)}
                                    className="text-slate-400 hover:text-red-500 transition-colors p-2 rounded-full"
                                >
                                    <XIcon className="w-5 h-5" />
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
            
            {products.length > 0 && (
                <footer className="p-6 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50 flex justify-between items-center">
                    <button
                        onClick={onClear}
                        className="text-sm text-slate-600 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400 font-semibold transition-colors"
                    >
                        {t('favorites_modal_clear_all')}
                    </button>
                     <a 
                        href="#contact" 
                        onClick={onClose}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-md transition-colors"
                     >
                        {t('favorites_modal_quote_button')}
                     </a>
                </footer>
            )}
        </Modal>
    );
};

export default FavoritesModal;
