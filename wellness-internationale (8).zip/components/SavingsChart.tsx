import React from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';

type ChartData = {
    label: string;
    value: number;
    color: string;
};

type SavingsChartProps = {
    data: ChartData[];
};

const SavingsChart: React.FC<SavingsChartProps> = ({ data }) => {
    const { t } = useTranslations();
    const maxValue = Math.max(...data.map(d => d.value), 200); // Ensure a minimum height

    return (
        <div className="w-full h-64 bg-slate-200/50 dark:bg-slate-600/30 rounded-lg p-4 flex flex-col justify-end">
            <div className="flex justify-around items-end h-full gap-4">
                {data.map((item, index) => {
                    const barHeight = maxValue > 0 ? (item.value / maxValue) * 100 : 0;
                    return (
                        <div key={index} className="flex flex-col items-center w-1/3">
                            <div className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-1">
                                €{item.value.toFixed(0)}
                            </div>
                            <div
                                className={`w-full rounded-t-md ${item.color} transition-all duration-700 ease-out`}
                                style={{ height: `${barHeight}%` }}
                                title={`${item.label}: €${item.value.toFixed(2)}`}
                            ></div>
                            <div className="text-xs text-center mt-2 text-slate-600 dark:text-slate-300 font-medium">
                                {item.label}
                            </div>
                        </div>
                    );
                })}
            </div>
             <div className="flex justify-center text-xs text-slate-500 dark:text-slate-400 border-t border-slate-300 dark:border-slate-600 mt-2 pt-2">
                <div className="flex items-center mr-4"><div className="w-3 h-3 rounded-sm bg-red-400 dark:bg-red-500 mr-2"></div>{t('calculator_chart_bottles')}</div>
                <div className="flex items-center"><div className="w-3 h-3 rounded-sm bg-green-400 dark:bg-green-500 mr-2"></div>{t('calculator_chart_generator')}</div>
            </div>
        </div>
    );
};

export default SavingsChart;
