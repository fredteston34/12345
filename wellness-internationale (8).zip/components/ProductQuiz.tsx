import React, { useState, useMemo } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { SpinnerIcon } from './Icons.tsx';
import type { Product } from '../types.ts';
import { getProductData } from '../lib/product-data.ts';

const ProductQuiz: React.FC = () => {
    const { t } = useTranslations();
    const [step, setStep] = useState(0);
    const [answers, setAnswers] = useState({ q1: '', q2: '' });
    const [recommendation, setRecommendation] = useState<Product | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const productData = useMemo(() => getProductData(t), [t]);
    const homeSuggestion = useMemo(() => productData.find(p => p.id === 'home20'), [productData]);
    const officeSuggestion = useMemo(() => productData.find(p => p.id === 'office100'), [productData]);

    const handleAnswer = (question: 'q1' | 'q2', answer: string) => {
        setAnswers(prev => ({ ...prev, [question]: answer }));
        if (step === 1) {
             setStep(2);
        }
    };
    
    const getRecommendation = async () => {
        setIsLoading(true);
        setStep(3); // Move to loading step immediately
        
        try {
            const response = await fetch('/api/quiz-recommendation', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ answers })
            });
            
            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'API call failed');
            }

            const foundProduct = productData.find(p => p.id === result.recommendedId);
            setRecommendation(foundProduct || productData[0]);

        } catch (error) {
            console.error("Error fetching recommendation:", error);
            // Fallback to simple logic in case of API error
            const fallbackId = answers.q1 === t('quiz_q1_option3') ? 'industry500' : answers.q1 === t('quiz_q1_option2') ? 'office100' : 'home20';
            setRecommendation(productData.find(p => p.id === fallbackId) || null);
        } finally {
            setIsLoading(false);
        }
    };

    const resetQuiz = () => {
        setStep(0);
        setAnswers({ q1: '', q2: '' });
        setRecommendation(null);
    };

    const handleSuggestionClick = (productId: string) => {
        const element = document.getElementById(`product-${productId}`);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };
    
    const Question1 = () => (
        <div>
            <h3 className="text-2xl font-semibold mb-6 text-slate-800 dark:text-slate-100">{t('quiz_question_1')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[t('quiz_q1_option1'), t('quiz_q1_option2'), t('quiz_q1_option3')].map(option => (
                    <button key={option} onClick={() => handleAnswer('q1', option)} className="p-6 bg-white dark:bg-slate-700 rounded-lg shadow-md hover:shadow-lg hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-all text-lg font-medium text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        {option}
                    </button>
                ))}
            </div>
        </div>
    );
    
    const Question2 = () => (
         <div>
            <h3 className="text-2xl font-semibold mb-6 text-slate-800 dark:text-slate-100">{t('quiz_question_2')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[t('quiz_q2_option1'), t('quiz_q2_option2'), t('quiz_q2_option3')].map(option => (
                    <button key={option} onClick={() => { handleAnswer('q2', option); getRecommendation(); }} className="p-6 bg-white dark:bg-slate-700 rounded-lg shadow-md hover:shadow-lg hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-all text-lg font-medium text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        {option}
                    </button>
                ))}
            </div>
        </div>
    );

    const renderStep = () => {
        switch (step) {
            case 1: return <Question1 />;
            case 2: return <Question2 />;
            case 3:
                if (isLoading) {
                    return <div className="text-center"><SpinnerIcon className="w-12 h-12 text-blue-600 dark:text-blue-500 mx-auto" /><p className="mt-4 text-lg font-semibold">{t('quiz_loading')}</p></div>;
                }
                if (recommendation) {
                    return (
                        <div className="text-center">
                            <h3 className="text-2xl font-semibold mb-2 text-slate-800 dark:text-slate-100">{t('quiz_result_title')}</h3>
                            <p className="text-slate-600 dark:text-slate-300 mb-6 max-w-lg mx-auto">{t('quiz_result_desc')}</p>
                            <div className="bg-white dark:bg-slate-700 p-6 rounded-lg shadow-lg max-w-sm mx-auto">
                                <img src={recommendation.imageSrc} alt={recommendation.name} className="w-full h-48 object-cover rounded-md mb-4" />
                                <h4 className="text-xl font-bold text-slate-900 dark:text-slate-100">{recommendation.name}</h4>
                                <p className="text-blue-600 dark:text-blue-400 font-semibold mb-3">{recommendation.capacity}</p>
                                <a href={`#product-${recommendation.id}`} className="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full transition-colors">
                                    {t('quiz_result_view_product')}
                                </a>
                            </div>
                             <button onClick={resetQuiz} className="mt-8 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 font-semibold transition-colors">
                                {t('quiz_restart_button')}
                            </button>
                        </div>
                    );
                }
                return null;
            default:
                return (
                    <div className="w-full">
                        <h3 className="text-xl font-bold text-center text-slate-800 dark:text-slate-100 mb-6">{t('quiz_suggestions_title')}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                            {[homeSuggestion, officeSuggestion].map(product => {
                                if (!product) return null;
                                return (
                                    <div key={product.id} className="bg-white dark:bg-slate-700/50 p-6 rounded-lg shadow-lg flex flex-col text-center transition-all duration-300 transform hover:scale-105 hover:shadow-xl">
                                        <img src={product.imageSrc} alt={product.name} className="w-full h-32 object-cover rounded-md mb-4" />
                                        <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100">{product.name}</h4>
                                        <p className="text-sm text-blue-600 dark:text-blue-400 font-semibold mb-3">{product.capacity}</p>
                                        <p className="text-sm text-slate-600 dark:text-slate-300 flex-grow px-2 mb-4">{product.description}</p>
                                        <div className="mt-auto pt-4">
                                            <button 
                                                onClick={() => handleSuggestionClick(product.id)}
                                                className="inline-block bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-800 dark:text-slate-100 font-semibold py-2 px-5 rounded-full text-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500"
                                            >
                                                {t('quiz_view_suggestion_cta')}
                                            </button>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                        
                        <div className="flex items-center my-6">
                            <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
                            <span className="flex-shrink mx-4 text-slate-500 dark:text-slate-400 font-semibold tracking-wider">{t('quiz_divider_text')}</span>
                            <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
                        </div>
            
                        <div className="text-center">
                            <button onClick={() => setStep(1)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-transform duration-300 transform hover:scale-105">
                                {t('quiz_start_button')}
                            </button>
                        </div>
                    </div>
                );
        }
    };

    return (
        <section id="quiz" className="py-20 bg-blue-50 dark:bg-slate-800 scroll-mt-20">
            <div className="container mx-auto px-6">
                 <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('quiz_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('quiz_subtitle')}
                    </p>
                </div>
                <div className="max-w-4xl mx-auto p-8 bg-slate-100 dark:bg-slate-900/50 rounded-2xl shadow-xl min-h-[20rem] flex items-center justify-center">
                   {renderStep()}
                </div>
            </div>
        </section>
    );
};

export default ProductQuiz;