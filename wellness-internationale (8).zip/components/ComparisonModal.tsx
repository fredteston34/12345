
import React from 'react';
import { XIcon } from './Icons.tsx';
import type { Product } from '../types.ts';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';


type ComparisonModalProps = {
    products: Product[];
    onClose: () => void;
};

const ComparisonModal: React.FC<ComparisonModalProps> = ({ products, onClose }) => {
    const { t } = useTranslations();

    const allFeatures = Array.from(new Set(products.flatMap(p => p.features)));

    return (
        <Modal onClose={onClose} panelClassName="max-w-4xl">
            <header className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{t('compare_modal_title')}</h2>
                <button onClick={onClose} aria-label={t('compare_modal_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="overflow-x-auto flex-grow">
                <table className="w-full text-left">
                    <thead className="sticky top-0 bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="p-4 font-semibold text-slate-700 dark:text-slate-200 w-1/4">{t('compare_modal_feature')}</th>
                            {products.map(product => (
                                <th key={product.name} className="p-4 font-semibold text-slate-700 dark:text-slate-200 w-1/4">
                                    <div className="flex flex-col items-center text-center">
                                        <img src={product.imageSrc} alt={product.name} className="w-24 h-24 object-cover rounded-lg mb-2"/>
                                        <span className="text-lg">{product.name}</span>
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                        <tr className="bg-slate-50 dark:bg-slate-700/50">
                            <td className="p-4 font-medium text-slate-600 dark:text-slate-300">{t('compare_modal_capacity')}</td>
                            {products.map(product => (
                                <td key={product.name} className="p-4 text-center font-bold text-blue-600 dark:text-blue-400">{product.capacity}</td>
                            ))}
                        </tr>
                         <tr>
                            <td className="p-4 font-medium text-slate-600 dark:text-slate-300">{t('compare_modal_type')}</td>
                            {products.map(product => (
                                <td key={product.name} className="p-4 text-center text-slate-800 dark:text-slate-200">
                                    <div className="flex items-center justify-center gap-2">
                                        {product.icon}
                                        {product.type}
                                    </div>
                                </td>
                            ))}
                        </tr>
                        {allFeatures.map(feature => (
                            <tr key={feature}>
                                <td className="p-4 font-medium text-slate-600 dark:text-slate-300">{feature}</td>
                                {products.map(product => (
                                    <td key={product.name} className="p-4 text-center">
                                        {product.features.includes(feature) ? (
                                            <svg className="w-6 h-6 text-green-500 dark:text-green-400 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        ) : (
                                            <span className="text-slate-400">-</span>
                                        )}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            <footer className="p-6 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50 flex justify-end gap-4">
                 {products.map(product => (
                     <a 
                        key={product.name}
                        href="#contact" 
                        onClick={onClose}
                        className="bg-slate-700 hover:bg-slate-800 text-white font-semibold py-2 px-4 rounded-lg text-center transition-colors text-sm dark:bg-blue-600 dark:hover:bg-blue-700"
                     >
                        {t('compare_modal_quote_button', product.name)}
                     </a>
                ))}
            </footer>
        </Modal>
    );
};

export default ComparisonModal;
