
import React from 'react';
import { XIcon } from './Icons.tsx';
import type { Product } from '../types.ts';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';

type ThreeDModalProps = {
    product: Product;
    onClose: () => void;
};

const ThreeDModal: React.FC<ThreeDModalProps> = ({ product, onClose }) => {
    const { t } = useTranslations();

    return (
        <Modal 
            onClose={onClose} 
            panelClassName="!bg-slate-900 !bg-grid-slate-800/[0.2] !text-white max-w-2xl"
            // The style needs to be applied directly as Tailwind doesn't support this complex background via a class
            // This is an inline style, so it remains.
        >
            <style>{`.!bg-grid-slate-800\\[\\/0\\.2\\] { background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.1) 1px, transparent 0); }`}</style>
            <header className="flex justify-between items-center p-6 border-b border-slate-700">
                <h2 className="text-2xl font-bold">{t('threed_modal_title')} - {product.name}</h2>
                <button onClick={onClose} aria-label={t('threed_modal_close_aria')} className="text-slate-400 hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="flex-grow flex flex-col items-center justify-center p-8">
                {/* Placeholder for a 3D model viewer */}
                <div className="w-64 h-64 mb-8">
                    <img src={product.imageSrc} alt={product.name} className="w-full h-full object-contain animate-pulse" style={{ animation: 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite' }} />
                </div>
                <p className="text-slate-300 text-center mb-6">{t('threed_modal_desc')}</p>
                <button 
                    className="bg-blue-600 hover:bg-blue-700 font-bold py-3 px-8 rounded-full text-lg transition-transform duration-300 transform hover:scale-105"
                >
                    {t('threed_modal_ar_button')}
                </button>
            </div>
        </Modal>
    );
};

export default ThreeDModal;
