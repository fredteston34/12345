

import React from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import AnimatedSection from './AnimatedSection.tsx';
import { SpinnerIcon, WarningIcon } from './Icons.tsx';
import type { TimelineItem } from '../lib/content-data.ts';
import { useQuery } from '@tanstack/react-query';
import { fetchContent } from '../lib/api.ts';

const Timeline: React.FC = () => {
    const { t, language } = useTranslations();

    const { data: timelineData, isLoading, error } = useQuery<TimelineItem[], Error>({
        queryKey: ['content', 'timeline', language],
        queryFn: () => fetchContent<TimelineItem[]>('timeline', language),
        initialData: [],
    });

    return (
        <section id="timeline" className="py-20 bg-white dark:bg-slate-900/50" aria-live="polite" aria-busy={isLoading}>
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('timeline_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('timeline_subtitle')}
                    </p>
                </div>
            </div>
            {isLoading && (
                <div className="flex justify-center items-center py-10">
                    <SpinnerIcon className="w-10 h-10 text-blue-600 dark:text-blue-500" />
                </div>
            )}
            {error && (
                <div className="text-center py-10 text-red-500 flex justify-center items-center gap-2">
                    <WarningIcon /> {error.message || 'Could not load timeline.'}
                </div>
            )}
            {!isLoading && !error && (
                <div className="relative w-full">
                    <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 dark:bg-slate-700 -translate-y-1/2"></div>
                    <div className="overflow-x-auto timeline-scrollbar pb-8">
                        <div className="flex w-max mx-auto px-6 sm:px-12 md:px-20 lg:px-32">
                            {timelineData.map((item, index) => (
                                <div key={index} className="flex-shrink-0 w-64 md:w-72 px-4">
                                    <AnimatedSection>
                                        <div className="relative pt-12">
                                            <div className="absolute top-0 left-1/2 w-4 h-4 bg-blue-600 dark:bg-blue-500 rounded-full -translate-x-1/2 border-4 border-white dark:border-slate-900/50"></div>
                                            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
                                                <p className="text-2xl font-bold text-blue-600 dark:text-blue-500 mb-2">{item.year}</p>
                                                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">{item.title}</h3>
                                                <p className="text-sm text-slate-600 dark:text-slate-300">{item.description}</p>
                                            </div>
                                        </div>
                                    </AnimatedSection>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
};

export default Timeline;