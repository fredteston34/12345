
import React, { useEffect } from 'react';

type ModalProps = {
    onClose: () => void;
    children: React.ReactNode;
    panelClassName?: string;
};

const Modal: React.FC<ModalProps> = ({ onClose, children, panelClassName = '' }) => {

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [onClose]);

    return (
        <div
            className="fixed inset-0 bg-black bg-opacity-70 z-[100] flex items-center justify-center p-4 animate-fade-in"
            aria-modal="true"
            role="dialog"
            onClick={onClose}
        >
            <div 
                className={`bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-h-[90vh] flex flex-col ${panelClassName}`}
                onClick={(e) => e.stopPropagation()}
            >
                {children}
            </div>
        </div>
    );
};

export default Modal;
