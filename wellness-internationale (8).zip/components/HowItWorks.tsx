import React, { useState, useEffect, useRef } from 'react';
import { AirIcon, FilterIcon, SnowflakeIcon, ShieldCheckIcon, WaterDropIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';

const HowItWorks: React.FC = () => {
    const { t } = useTranslations();
    const [activeStep, setActiveStep] = useState(0);
    const stepRefs = useRef<(HTMLDivElement | null)[]>([]);

    const steps = [
        {
            icon: <AirIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />,
            title: t('hiw_step1_title'),
            description: t('hiw_step1_desc'),
            nav: t('hiw_nav_aspiration'),
        },
        {
            icon: <FilterIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />,
            title: t('hiw_step2_title'),
            description: t('hiw_step2_desc'),
            nav: t('hiw_nav_filtration'),
        },
        {
            icon: <SnowflakeIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />,
            title: t('hiw_step3_title'),
            description: t('hiw_step3_desc'),
            nav: t('hiw_nav_condensation'),
        },
        {
            icon: <ShieldCheckIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />,
            title: t('hiw_step4_title'),
            description: t('hiw_step4_desc'),
            nav: t('hiw_nav_purification'),
        },
        {
            icon: <WaterDropIcon className="w-12 h-12 text-blue-600 dark:text-blue-500" />,
            title: t('hiw_step5_title'),
            description: t('hiw_step5_desc'),
            nav: t('hiw_nav_disponible'),
        }
    ];

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const index = stepRefs.current.findIndex(ref => ref === entry.target);
                        if (index !== -1) {
                            setActiveStep(index);
                        }
                    }
                });
            },
            { rootMargin: '-40% 0px -40% 0px', threshold: 0.1 }
        );

        const currentRefs = stepRefs.current;
        currentRefs.forEach((ref) => {
            if (ref) observer.observe(ref);
        });

        return () => {
            currentRefs.forEach((ref) => {
                if (ref) observer.unobserve(ref);
            });
        };
    }, []);
    
    const handleNavClick = (index: number) => {
        setActiveStep(index);
        stepRefs.current[index]?.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
        });
    };

    return (
        <section id="fonctionnement" className="py-20 bg-white dark:bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('hiw_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('hiw_subtitle')}
                    </p>
                </div>
                
                {/* Animated Explainer Section */}
                <div className="relative max-w-2xl mx-auto mb-20 p-8 bg-slate-50 dark:bg-slate-800 rounded-2xl shadow-lg min-h-[24rem] flex flex-col justify-center text-center">
                    <div key={activeStep} className="animate-fade-in-fast" aria-live="polite">
                        <div className="flex justify-center items-center mb-6 bg-blue-100 dark:bg-blue-900/50 rounded-full w-28 h-28 mx-auto ring-4 ring-white dark:ring-slate-700">
                             {React.cloneElement(steps[activeStep].icon, { className: "w-16 h-16 text-blue-600 dark:text-blue-500" })}
                        </div>
                        <h3 className="text-2xl font-bold mb-3 text-slate-800 dark:text-slate-100">{steps[activeStep].title}</h3>
                        <p className="text-slate-600 dark:text-slate-300 max-w-md mx-auto">{steps[activeStep].description}</p>
                    </div>
                </div>


                <div className="flex justify-center flex-wrap gap-x-4 gap-y-3 mb-12" role="tablist" aria-label="Navigation des étapes">
                    {steps.map((step, index) => (
                        <button
                            key={index}
                            role="tab"
                            aria-selected={activeStep === index}
                            aria-controls={`step-panel-${index}`}
                            id={`step-tab-${index}`}
                            onClick={() => handleNavClick(index)}
                            className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors duration-300 ${activeStep === index ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-700 hover:bg-blue-100 hover:text-blue-800 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-blue-900/50 dark:hover:text-blue-300'}`}
                        >
                            {step.nav}
                        </button>
                    ))}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
                    {steps.map((step, index) => (
                        <div 
                            key={index} 
                            id={`step-panel-${index}`}
                            role="tabpanel"
                            aria-labelledby={`step-tab-${index}`}
                            ref={(el) => { stepRefs.current[index] = el; }}
                            className={`text-center p-6 bg-slate-50 dark:bg-slate-800 rounded-xl scroll-mt-24 transition-all duration-300 ${activeStep === index ? 'ring-2 ring-blue-500 ring-offset-2 dark:ring-offset-slate-900 shadow-xl transform scale-105' : 'shadow-sm dark:shadow-md'}`}
                        >
                            <div className="flex justify-center items-center mb-4 bg-blue-100 dark:bg-blue-900/50 rounded-full w-24 h-24 mx-auto">
                                {step.icon}
                            </div>
                            <h3 className="text-xl font-semibold mb-2 text-slate-800 dark:text-slate-100">{step.title}</h3>
                            <p className="text-slate-600 dark:text-slate-300">{step.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default HowItWorks;