

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { XIcon, ChevronLeftIcon, ChevronRightIcon, ViewGridIcon, SlideshowIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import Modal from './Modal.tsx';

type ImageType = {
    src: string;
    srcSet: string;
    sizes: string;
    alt: string;
    title: string;
    description: string;
};

const placeholderSvg = (text: string) => `data:image/svg+xml,%3Csvg width='800' height='600' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='100%25' height='100%25' fill='%23e2e8f0'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='40' fill='%2394a3b8' text-anchor='middle' dy='.3em'%3E${encodeURIComponent(text)}%3C/text%3E%3C/svg%3E`;


const ParallaxGridItem: React.FC<{
    image: ImageType;
    onClick: () => void;
}> = ({ image, onClick }) => {
    const itemRef = useRef<HTMLDivElement>(null);
    const [translateY, setTranslateY] = useState(0);
    const PARALLAX_INTENSITY = 20;

    useEffect(() => {
        const rafId = { current: 0 };

        const handleScroll = () => {
            if (!itemRef.current) return;
            const rect = itemRef.current.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            if (rect.top < viewportHeight && rect.bottom > 0) {
                const elementCenter = rect.top + rect.height / 2;
                const progress = (elementCenter - viewportHeight / 2) / (viewportHeight / 2);
                const offset = -progress * PARALLAX_INTENSITY;
                setTranslateY(offset);
            }
        };
        
        const handleScrollRaf = () => {
            cancelAnimationFrame(rafId.current);
            rafId.current = requestAnimationFrame(handleScroll);
        };
        
        window.addEventListener('scroll', handleScrollRaf, { passive: true });
        handleScrollRaf();

        return () => {
            window.removeEventListener('scroll', handleScrollRaf);
            cancelAnimationFrame(rafId.current);
        };
    }, []);

    return (
        <div
            ref={itemRef}
            role="button"
            tabIndex={0}
            aria-label={image.alt}
            className="relative overflow-hidden rounded-lg shadow-md hover:shadow-xl group cursor-pointer transition-all duration-300 transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 motion-reduce:transform-none"
            onClick={onClick}
            onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onClick();
                }
            }}
        >
            <img
                src={image.src}
                alt={image.alt}
                loading="lazy"
                className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-500 motion-reduce:transform-none"
                style={{
                    transform: `scale(1.05) translateY(${translateY}px)`,
                }}
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-end p-4">
                <p className="text-white text-lg font-semibold opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                    {image.title}
                </p>
            </div>
        </div>
    );
};


const Gallery: React.FC = () => {
    const { t } = useTranslations();
    const [view, setView] = useState('grid'); 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
    const [currentSlide, setCurrentSlide] = useState(0);
    const [isPaused, setIsPaused] = useState(false);

    const intervalRef = useRef<number | null>(null);
    
    const galleryImages: ImageType[] = useMemo(() => [
        {
            src: placeholderSvg('Installation 1'),
            srcSet: '',
            sizes: '',
            alt: t('gallery1_alt'),
            title: t('gallery1_title'),
            description: t('gallery1_desc')
        },
        {
            src: placeholderSvg('Installation 2'),
            srcSet: '',
            sizes: '',
            alt: t('gallery2_alt'),
            title: t('gallery2_title'),
            description: t('gallery2_desc')
        },
        {
            src: placeholderSvg('Pure Water'),
            srcSet: '',
            sizes: '',
            alt: t('gallery3_alt'),
            title: t('gallery3_title'),
            description: t('gallery3_desc')
        },
        {
            src: placeholderSvg('Natural Integration'),
            srcSet: '',
            sizes: '',
            alt: t('gallery4_alt'),
            title: t('gallery4_title'),
            description: t('gallery4_desc')
        },
        {
            src: placeholderSvg('Industrial Use'),
            srcSet: '',
            sizes: '',
            alt: t('gallery5_alt'),
            title: t('gallery5_title'),
            description: t('gallery5_desc')
        },
        {
            src: placeholderSvg('Family Wellness'),
            srcSet: '',
            sizes: '',
            alt: t('gallery6_alt'),
            title: t('gallery6_title'),
            description: t('gallery6_desc')
        }
    ], [t]);

    const startAutoplay = useCallback(() => {
        if (intervalRef.current) clearInterval(intervalRef.current);
        intervalRef.current = window.setInterval(() => {
            setCurrentSlide((prev) => (prev + 1) % galleryImages.length);
        }, 5000);
    }, [galleryImages.length]);

    const pauseAutoplay = useCallback(() => {
        if (intervalRef.current) clearInterval(intervalRef.current);
    }, []);

    useEffect(() => {
        if (view === 'carousel' && !isPaused) {
            startAutoplay();
        } else {
            pauseAutoplay();
        }
        return () => pauseAutoplay();
    }, [view, isPaused, startAutoplay, pauseAutoplay]);

    const openModal = (index: number) => {
        setSelectedImageIndex(index);
        setIsModalOpen(true);
    };

    const closeModal = useCallback(() => {
        setIsModalOpen(false);
        setSelectedImageIndex(null);
    }, []);
    
    const showNextImage = useCallback(() => {
        if (selectedImageIndex === null) return;
        setSelectedImageIndex((prevIndex) => (prevIndex! + 1) % galleryImages.length);
    }, [selectedImageIndex, galleryImages.length]);

    const showPrevImage = useCallback(() => {
        if (selectedImageIndex === null) return;
        setSelectedImageIndex((prevIndex) => (prevIndex! - 1 + galleryImages.length) % galleryImages.length);
    }, [selectedImageIndex, galleryImages.length]);


    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (!isModalOpen) return;
            // The 'Escape' key is handled by the Modal component.
            if (e.key === 'ArrowRight') showNextImage();
            if (e.key === 'ArrowLeft') showPrevImage();
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isModalOpen, showNextImage, showPrevImage]);


    return (
        <section id="gallery" className="py-20 bg-white dark:bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-8">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('gallery_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('gallery_subtitle')}
                    </p>
                </div>

                <div className="flex justify-end mb-6">
                    <div className="flex items-center space-x-2 p-1 rounded-full bg-slate-100 dark:bg-slate-800">
                        <button onClick={() => setView('grid')} className={`p-2 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 ${view === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`} aria-label={t('gallery_grid_view_aria')}>
                            <ViewGridIcon className="w-5 h-5" />
                        </button>
                        <button onClick={() => setView('carousel')} className={`p-2 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 ${view === 'carousel' ? 'bg-blue-600 text-white' : 'text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`} aria-label={t('gallery_slideshow_view_aria')}>
                            <SlideshowIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>

                {view === 'grid' ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                        {galleryImages.map((image, index) => (
                           <ParallaxGridItem 
                                key={index} 
                                image={image} 
                                onClick={() => openModal(index)} 
                           />
                        ))}
                    </div>
                ) : (
                    <div className="relative w-full max-w-4xl mx-auto" onMouseEnter={() => setIsPaused(true)} onMouseLeave={() => setIsPaused(false)}>
                        <div className="relative h-96 md:h-[500px] overflow-hidden rounded-lg shadow-xl">
                            {galleryImages.map((image, index) => (
                                <div
                                    key={index}
                                    className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
                                >
                                    <img 
                                      src={image.src} 
                                      alt={image.alt} 
                                      className="w-full h-full object-cover" 
                                      loading="lazy"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                                    <div className="absolute bottom-0 left-0 p-6 text-white">
                                        <h3 className="text-2xl font-bold">{image.title}</h3>
                                        <p className="text-sm mt-1">{image.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                             {galleryImages.map((image, index) => (
                                <button 
                                    key={index} 
                                    onClick={() => setCurrentSlide(index)} 
                                    aria-label={t('gallery_carousel_go_to_aria', index + 1, image.title)}
                                    className={`w-3 h-3 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white ${index === currentSlide ? 'bg-white ring-2 ring-white/70' : 'bg-white/50 hover:bg-white'}`}></button>
                             ))}
                        </div>
                        <button 
                            onClick={() => setCurrentSlide((prev) => (prev - 1 + galleryImages.length) % galleryImages.length)} 
                            aria-label={t('gallery_modal_prev_aria')}
                            className="absolute top-1/2 left-4 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75 transition-colors focus:outline-none focus:ring-2 focus:ring-white">
                            <ChevronLeftIcon className="w-6 h-6" />
                        </button>
                        <button 
                            onClick={() => setCurrentSlide((prev) => (prev + 1 + galleryImages.length) % galleryImages.length)} 
                            aria-label={t('gallery_modal_next_aria')}
                            className="absolute top-1/2 right-4 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75 transition-colors focus:outline-none focus:ring-2 focus:ring-white">
                            <ChevronRightIcon className="w-6 h-6" />
                        </button>
                    </div>
                )}
            </div>

            {isModalOpen && selectedImageIndex !== null && (
                <Modal onClose={closeModal} panelClassName="!bg-transparent !shadow-none !w-auto !max-w-4xl !max-h-full">
                    <div className="relative">
                        <img
                            src={galleryImages[selectedImageIndex].src}
                            alt={galleryImages[selectedImageIndex].alt}
                            loading="lazy"
                            className="rounded-lg shadow-2xl object-contain max-h-[85vh]"
                        />
                        <p className="text-center text-white text-sm mt-2">{galleryImages[selectedImageIndex].alt}</p>
                        
                        <button onClick={closeModal} aria-label={t('gallery_modal_close_aria')} className="absolute top-0 right-0 -mt-2 -mr-8 text-white hover:text-gray-300 transition-colors focus:outline-none focus:ring-2 focus:ring-white rounded-full p-2 bg-black/30">
                            <XIcon className="w-8 h-8" />
                        </button>

                        <button onClick={showPrevImage} aria-label={t('gallery_modal_prev_aria')} className="absolute left-0 top-1/2 -translate-x-1/2 -ml-4 text-white bg-black bg-opacity-50 p-2 rounded-full hover:bg-opacity-75 transition-colors focus:outline-none focus:ring-2 focus:ring-white">
                            <ChevronLeftIcon className="w-8 h-8" />
                        </button>

                        <button onClick={showNextImage} aria-label={t('gallery_modal_next_aria')} className="absolute right-0 top-1/2 translate-x-1/2 -mr-4 text-white bg-black bg-opacity-50 p-2 rounded-full hover:bg-opacity-75 transition-colors focus:outline-none focus:ring-2 focus:ring-white">
                            <ChevronRightIcon className="w-8 h-8" />
                        </button>
                    </div>
                </Modal>
            )}
        </section>
    );
};

export default Gallery;