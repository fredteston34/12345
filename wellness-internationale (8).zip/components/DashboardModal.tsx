

import React, { useMemo, useState } from 'react';
import { useAppStore } from '../hooks/useAppStore.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { getProductData } from '../lib/product-data.ts';
import { XIcon, WaterDropIcon, EuroIcon, SpinnerIcon, CheckCircleIcon, WarningIcon } from './Icons.tsx';
import CircularProgress from './CircularProgress.tsx';
import Modal from './Modal.tsx';

const DashboardModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { userProductId, logout } = useAppStore();
    const { t } = useTranslations();
    const productDataList = useMemo(() => getProductData(t), [t]);
    const userProduct = productDataList.find(p => p.id === userProductId);
    
    const [isOrdering, setIsOrdering] = useState(false);
    const [orderStatus, setOrderStatus] = useState<{ success: boolean; message: string } | null>(null);

    if (!userProduct) {
        // This case should ideally not happen if the modal is opened correctly
        return null;
    }

    const handleLogout = () => {
        logout();
        onClose();
    };
    
    const handleOrderFilters = async () => {
        setIsOrdering(true);
        setOrderStatus(null);
        try {
            const response = await fetch('/api/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId: userProduct?.id }),
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Order failed');
            setOrderStatus({ success: true, message: result.message });
        } catch (err) {
            setOrderStatus({ success: false, message: err instanceof Error ? err.message : 'Order failed' });
        } finally {
            setIsOrdering(false);
            setTimeout(() => setOrderStatus(null), 5000);
        }
    };

    const filterLife = 85; // Mock data
    const waterProduced = 550; // Mock data
    const savings = 45; // Mock data

    return (
        <Modal onClose={onClose} panelClassName="max-w-3xl">
            <header className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{t('dashboard_title')}</h2>
                <button onClick={onClose} aria-label={t('dashboard_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>

            <div className="overflow-y-auto p-8 space-y-8">
                <div>
                    <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200 mb-4">{t('dashboard_my_products')}</h3>
                    <div className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg flex items-center gap-6">
                        <img src={userProduct.imageSrc} alt={userProduct.name} className="w-24 h-24 object-cover rounded-md flex-shrink-0" />
                        <div>
                            <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100">{userProduct.name}</h4>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{userProduct.capacity}</p>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200 mb-4">{t('dashboard_stats_title')}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                         <div className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg flex flex-col items-center justify-center text-center">
                            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">{t('dashboard_filter_status')}</p>
                            <CircularProgress percentage={filterLife} />
                            <p className="text-xs text-slate-400 dark:text-slate-500 mt-2">{t('dashboard_filter_life_remaining')}</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg flex items-center gap-3">
                            <WaterDropIcon className="w-8 h-8 text-blue-500 flex-shrink-0"/>
                            <div>
                                <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{waterProduced}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{t('dashboard_water_produced')}</p>
                            </div>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg flex items-center gap-3">
                            <EuroIcon className="w-8 h-8 text-green-500 flex-shrink-0"/>
                            <div>
                                <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">€{savings}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{t('dashboard_savings')}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer className="relative p-6 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50 flex justify-between items-center">
                <button onClick={handleLogout} className="text-sm text-slate-600 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400 font-semibold transition-colors">
                    {t('dashboard_logout_button')}
                </button>
                <button onClick={handleOrderFilters} disabled={isOrdering} aria-busy={isOrdering} className="w-48 flex justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-md transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed">
                    {isOrdering ? <SpinnerIcon className="w-5 h-5"/> : t('dashboard_order_filters_button')}
                </button>
                {orderStatus && (
                    <div className={`absolute bottom-full right-6 mb-2 p-3 rounded-lg text-sm shadow-lg animate-fade-in-fast flex items-center gap-2
                        ${orderStatus.success ? 'bg-green-100 text-green-900 dark:bg-green-900/50 dark:text-green-200' : 'bg-red-100 text-red-900 dark:bg-red-900/50 dark:text-red-200'}`}>
                       {orderStatus.success ? <CheckCircleIcon className="w-5 h-5"/> : <WarningIcon className="w-5 h-5"/>}
                       {orderStatus.message}
                    </div>
                )}
            </footer>
        </Modal>
    );
};

export default DashboardModal;