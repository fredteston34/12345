import React, { useState, useMemo } from 'react';
import { EuroIcon, BottleIcon, CheckCircleIcon, SparklesIcon, SpinnerIcon, WarningIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import SavingsChart from './SavingsChart.tsx';
import { getProductData } from '../lib/product-data.ts';

const SavingsCalculator: React.FC = () => {
    const { t } = useTranslations();
    const [householdSize, setHouseholdSize] = useState(2);
    const [bottlesPerWeek, setBottlesPerWeek] = useState(10);
    const [costPerBottle, setCostPerBottle] = useState(0.5);
    const [postalCode, setPostalCode] = useState('');
    const [aiResult, setAiResult] = useState<{
        recommendedProductId: string;
        annualSavings: number;
        investmentAmortizationYears: number;
        personalizedMessage: string;
    } | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisError, setAnalysisError] = useState('');

    const productDataList = useMemo(() => getProductData(t), [t]);

    const annualSavings = useMemo(() => {
        return (bottlesPerWeek * costPerBottle * 52);
    }, [bottlesPerWeek, costPerBottle]);

    const plasticSaved = useMemo(() => {
        return bottlesPerWeek * 52;
    }, [bottlesPerWeek]);
    
    const dailyWaterNeed = useMemo(() => {
        return householdSize * 2;
    }, [householdSize]);
    
    const estimatedGeneratorAnnualCost = 150; 
    
    const chartData = [
        { label: t('calculator_chart_bottles'), value: annualSavings, color: 'bg-red-400 dark:bg-red-500' },
        { label: t('calculator_chart_generator'), value: estimatedGeneratorAnnualCost, color: 'bg-green-400 dark:bg-green-500' }
    ];

    const handlePostalCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value.replace(/\D/g, '');
        if (value.length <= 5) {
            setPostalCode(value);
        }
    };

    const getAIPersonalization = async () => {
        if (postalCode.length !== 5) {
            setAnalysisError(t('calculator_error_postal_code'));
            return;
        }
        setIsAnalyzing(true);
        setAnalysisError('');
        setAiResult(null);

        try {
            const response = await fetch('/api/savings-analysis', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    postalCode,
                    householdSize,
                    bottlesPerWeek,
                    costPerBottle,
                    annualSavings,
                    estimatedGeneratorAnnualCost,
                })
            });
            
            const resultJson = await response.json();

            if (!response.ok) {
                throw new Error(resultJson.error || t('calculator_error_generic'));
            }
            
            setAiResult(resultJson);

        } catch (error) {
            console.error("AI Analysis Failed:", error);
            setAnalysisError(t('calculator_error_generic'));
        } finally {
            setIsAnalyzing(false);
        }
    };
    
    const recommendedProduct = productDataList.find(p => p.id === aiResult?.recommendedProductId);

    return (
        <section id="calculateur" className="py-20 bg-slate-50 dark:bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('calculator_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-3xl mx-auto">
                        {t('calculator_subtitle')}
                    </p>
                </div>

                <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-12 bg-white dark:bg-slate-800 p-8 md:p-12 rounded-2xl shadow-xl">
                    <div className="lg:col-span-2 space-y-8">
                        <div>
                            <label htmlFor="householdSize" className="flex justify-between items-center text-lg font-semibold text-slate-700 dark:text-slate-200">
                                {t('calculator_household_size')}
                                <span className="text-blue-600 dark:text-blue-400 font-bold">{householdSize} {householdSize > 1 ? t('calculator_people') : t('calculator_person')}</span>
                            </label>
                            <input
                                id="householdSize"
                                type="range"
                                min="1"
                                max="10"
                                value={householdSize}
                                onChange={(e) => setHouseholdSize(Number(e.target.value))}
                                className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer mt-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500"
                            />
                        </div>
                        <div>
                            <label htmlFor="bottlesPerWeek" className="flex justify-between items-center text-lg font-semibold text-slate-700 dark:text-slate-200">
                                {t('calculator_bottles_week')}
                                <span className="text-blue-600 dark:text-blue-400 font-bold">{bottlesPerWeek}</span>
                            </label>
                            <input
                                id="bottlesPerWeek"
                                type="range"
                                min="0"
                                max="50"
                                value={bottlesPerWeek}
                                onChange={(e) => setBottlesPerWeek(Number(e.target.value))}
                                className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer mt-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500"
                            />
                        </div>
                        <div>
                            <label htmlFor="costPerBottle" className="flex justify-between items-center text-lg font-semibold text-slate-700 dark:text-slate-200">
                                {t('calculator_cost_bottle')}
                                <span className="text-blue-600 dark:text-blue-400 font-bold">{costPerBottle.toFixed(2)} €</span>
                            </label>
                            <input
                                id="costPerBottle"
                                type="range"
                                min="0.2"
                                max="2"
                                step="0.05"
                                value={costPerBottle}
                                onChange={(e) => setCostPerBottle(Number(e.target.value))}
                                className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer mt-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500"
                            />
                        </div>
                         <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                             <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">{t('calculator_ai_title')}</h3>
                             <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('calculator_ai_subtitle')}</p>
                             <div className="flex gap-2">
                                <input
                                    id="postalCode"
                                    type="text"
                                    value={postalCode}
                                    onChange={handlePostalCodeChange}
                                    placeholder={t('calculator_postal_code')}
                                    className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-500 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
                                />
                                <button onClick={getAIPersonalization} disabled={isAnalyzing} className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition-all disabled:bg-blue-400">
                                    {isAnalyzing ? <SpinnerIcon className="w-5 h-5"/> : <SparklesIcon className="w-5 h-5" />}
                                    <span>{isAnalyzing ? t('calculator_analyzing') : t('calculator_analyze_button')}</span>
                                </button>
                             </div>
                        </div>
                    </div>

                    <div className="lg:col-span-3 bg-slate-100 dark:bg-slate-700 p-8 rounded-lg flex flex-col justify-center">
                        {!aiResult && !isAnalyzing && !analysisError && (
                            <>
                                <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-6 text-center">{t('calculator_results_title')}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-semibold text-slate-700 dark:text-slate-200 mb-4">{t('calculator_chart_title')}</h4>
                                        <SavingsChart data={chartData} />
                                    </div>
                                    <div className="space-y-4">
                                       <div className="bg-white dark:bg-slate-600 p-4 rounded-lg shadow-sm flex items-center">
                                            <EuroIcon className="w-8 h-8 text-green-500 mr-4"/>
                                            <div>
                                                <p className="text-2xl font-extrabold text-green-600 dark:text-green-400">{annualSavings.toFixed(0)} €</p>
                                                <p className="text-sm text-slate-500 dark:text-slate-300">{t('calculator_savings')}</p>
                                            </div>
                                       </div>
                                       <div className="bg-white dark:bg-slate-600 p-4 rounded-lg shadow-sm flex items-center">
                                            <BottleIcon className="w-8 h-8 text-blue-500 mr-4"/>
                                            <div>
                                                <p className="text-2xl font-extrabold text-blue-600 dark:text-blue-400">{plasticSaved}</p>
                                                <p className="text-sm text-slate-500 dark:text-slate-300">{t('calculator_plastic_saved')}</p>
                                            </div>
                                       </div>
                                       <div className="bg-white dark:bg-slate-600 p-4 rounded-lg shadow-sm flex items-center">
                                            <CheckCircleIcon className="w-8 h-8 text-teal-500 mr-4"/>
                                            <div>
                                                <p className="text-lg font-bold text-teal-600 dark:text-teal-400">{t('calculator_water_autonomy')}</p>
                                                <p className="text-sm text-slate-500 dark:text-slate-300">{t('calculator_water_needs', dailyWaterNeed)}</p>
                                            </div>
                                       </div>
                                       <a href="#produits" className="block w-full text-center mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full text-md transition-transform duration-300 transform hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500">
                                            {t('calculator_cta')}
                                        </a>
                                    </div>
                                </div>
                            </>
                        )}
                        {(isAnalyzing || analysisError || aiResult) && (
                            <div className="animate-fade-in text-center">
                                {isAnalyzing && <SpinnerIcon className="w-12 h-12 text-blue-500 mx-auto" />}
                                {analysisError && <div className="p-4 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-lg flex items-center justify-center gap-2"><WarningIcon className="w-5 h-5"/> {analysisError}</div>}
                                {aiResult && recommendedProduct && (
                                    <div>
                                        <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-4">{t('calculator_ai_result_title')}</h3>
                                        <p className="text-slate-600 dark:text-slate-300 italic mb-6">"{aiResult.personalizedMessage}"</p>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            <div className="bg-white dark:bg-slate-600 p-4 rounded-lg shadow">
                                                <p className="text-sm text-slate-500 dark:text-slate-300">{t('calculator_recommended_product')}</p>
                                                <p className="text-xl font-bold text-blue-600 dark:text-blue-400">{recommendedProduct.name}</p>
                                            </div>
                                            <div className="bg-white dark:bg-slate-600 p-4 rounded-lg shadow">
                                                <p className="text-sm text-slate-500 dark:text-slate-300">{t('calculator_amortization')}</p>
                                                <p className="text-xl font-bold text-green-600 dark:text-green-400">
                                                    {aiResult.investmentAmortizationYears < 99 ? `${aiResult.investmentAmortizationYears.toFixed(1)} ${t('calculator_years')}` : '> 10 ans'}
                                                </p>
                                            </div>
                                        </div>
                                         <a href="#produits" className="block w-full mt-6 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-full text-md transition-transform duration-300 transform hover:scale-105">
                                            {t('calculator_view_product')}
                                        </a>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default SavingsCalculator;