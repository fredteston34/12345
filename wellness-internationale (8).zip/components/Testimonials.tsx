

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ChevronLeftIcon, ChevronRightIcon, SpinnerIcon, WarningIcon } from './Icons.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import type { TestimonialItem } from '../lib/content-data.ts';
import { useQuery } from '@tanstack/react-query';
import { fetchContent } from '../lib/api.ts';

const Testimonials: React.FC = () => {
    const { t, language } = useTranslations();
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const intervalRef = useRef<number | null>(null);

    const { data: testimonialsData, isLoading, error } = useQuery<TestimonialItem[], Error>({
        queryKey: ['content', 'testimonials', language],
        queryFn: () => fetchContent<TestimonialItem[]>('testimonials', language),
        initialData: [],
    });

    const nextTestimonial = useCallback(() => {
        if (testimonialsData.length === 0) return;
        setCurrentIndex(prevIndex => (prevIndex + 1) % testimonialsData.length);
    }, [testimonialsData.length]);

    const prevTestimonial = () => {
        if (testimonialsData.length === 0) return;
        setCurrentIndex(prevIndex => (prevIndex - 1 + testimonialsData.length) % testimonialsData.length);
    };

    const startAutoplay = useCallback(() => {
        if (intervalRef.current) clearInterval(intervalRef.current);
        intervalRef.current = window.setInterval(nextTestimonial, 6000);
    }, [nextTestimonial]);

    useEffect(() => {
        if (!isPaused && testimonialsData.length > 0) {
            startAutoplay();
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isPaused, startAutoplay, testimonialsData.length]);

    return (
        <section id="temoignages" className="py-20 bg-slate-100 dark:bg-slate-800" aria-live="polite" aria-busy={isLoading}>
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('testimonials_title')}</h2>
                    <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        {t('testimonials_subtitle')}
                    </p>
                </div>
                <div
                    className="relative max-w-3xl mx-auto"
                    onMouseEnter={() => setIsPaused(true)}
                    onMouseLeave={() => setIsPaused(false)}
                >
                    <div className="relative h-80 overflow-hidden rounded-xl shadow-lg">
                        {isLoading && (
                            <div className="w-full h-full flex justify-center items-center bg-white dark:bg-slate-700">
                                <SpinnerIcon className="w-10 h-10 text-blue-600 dark:text-blue-500" />
                            </div>
                        )}
                        {error && (
                            <div className="w-full h-full flex justify-center items-center bg-red-50 dark:bg-red-900/30 text-red-500 gap-2">
                                <WarningIcon /> {error.message || 'Could not load testimonials.'}
                            </div>
                        )}
                        {!isLoading && !error && testimonialsData.map((testimonial, index) => (
                            <div
                                key={index}
                                className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                                    index === currentIndex ? 'opacity-100 translate-x-0' : 'opacity-0'
                                } ${ index > currentIndex ? 'translate-x-full' : ''} ${ index < currentIndex ? '-translate-x-full' : ''}`}
                                aria-hidden={index !== currentIndex}
                            >
                                <div className="bg-white dark:bg-slate-700 p-8 rounded-xl h-full flex flex-col justify-center">
                                    <svg className="w-10 h-10 text-blue-200 dark:text-blue-600/50 mb-4" fill="currentColor" viewBox="0 0 32 32" aria-hidden="true">
                                        <path d="M9.33 6.98C6.9 9.1 5.1 11.66 5.1 15.14c0 4.1 2.83 6.88 6.42 6.88 3.58 0 6.42-2.78 6.42-6.88 0-4.04-2.83-6.82-6.42-6.82-.43 0-.85.06-1.25.16a5.27 5.27 0 00-1.04-.14zM20.53 6.98c-2.43 2.12-4.23 4.68-4.23 8.16 0 4.1 2.83 6.88 6.42 6.88s6.42-2.78 6.42-6.88c0-4.04-2.83-6.82-6.42-6.82-.43 0-.85.06-1.25.16a5.27 5.27 0 00-1.04-.14z" />
                                    </svg>
                                    <blockquote className="text-slate-600 dark:text-slate-300 italic">
                                        <p>"{testimonial.quote}"</p>
                                    </blockquote>
                                    <figcaption className="mt-6">
                                        <div className="font-semibold text-slate-900 dark:text-slate-100">{testimonial.name}</div>
                                        <div className="text-slate-500 dark:text-slate-400 text-sm">{testimonial.location}</div>
                                    </figcaption>
                                </div>
                            </div>
                        ))}
                    </div>
                    {testimonialsData.length > 1 && (
                        <>
                            <button
                                onClick={prevTestimonial}
                                aria-label={t('testimonial_prev_aria')}
                                className="absolute top-1/2 -left-4 md:-left-12 transform -translate-y-1/2 bg-white dark:bg-slate-600 text-slate-600 dark:text-slate-200 p-2 rounded-full shadow-md hover:bg-slate-100 dark:hover:bg-slate-500 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-800"
                            >
                                <ChevronLeftIcon className="w-6 h-6" />
                            </button>
                            <button
                                onClick={nextTestimonial}
                                aria-label={t('testimonial_next_aria')}
                                className="absolute top-1/2 -right-4 md:-right-12 transform -translate-y-1/2 bg-white dark:bg-slate-600 text-slate-600 dark:text-slate-200 p-2 rounded-full shadow-md hover:bg-slate-100 dark:hover:bg-slate-500 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-800"
                            >
                                <ChevronRightIcon className="w-6 h-6" />
                            </button>
                            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                                {testimonialsData.map((_, index) => (
                                    <button
                                        key={index}
                                        onClick={() => setCurrentIndex(index)}
                                        aria-label={t('testimonial_go_to_aria', index + 1)}
                                        className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${index === currentIndex ? 'bg-blue-600 dark:bg-blue-400 scale-125' : 'bg-slate-300 dark:bg-slate-500 hover:bg-slate-400 dark:hover:bg-slate-400'}`}
                                   />
                                ))}
                            </div>
                        </>
                    )}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;