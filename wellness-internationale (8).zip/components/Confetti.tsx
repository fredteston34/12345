import React, { useMemo } from 'react';

const Confetti: React.FC = () => {
    const confettiPieces = useMemo(() => {
        return Array.from({ length: 50 }).map((_, i) => {
            const style = {
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                backgroundColor: ['#3b82f6', '#ef4444', '#f59e0b', '#10b981'][Math.floor(Math.random() * 4)],
            };
            return <div key={i} className="confetti" style={style}></div>;
        });
    }, []);

    return <div className="absolute inset-0 pointer-events-none overflow-hidden z-50">{confettiPieces}</div>;
};

export default Confetti;