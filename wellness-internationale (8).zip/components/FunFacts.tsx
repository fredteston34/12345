import React, { useState, useMemo } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { WaterDropIcon } from './Icons.tsx';

const FunFacts: React.FC = () => {
    const { t } = useTranslations();
    
    const facts = useMemo(() => [
        t('fun_fact_1'),
        t('fun_fact_2'),
        t('fun_fact_3'),
        t('fun_fact_4'),
        t('fun_fact_5'),
    ], [t]);
    
    const [currentFactIndex, setCurrentFactIndex] = useState(0);

    const showNewFact = () => {
        setCurrentFactIndex(prevIndex => (prevIndex + 1) % facts.length);
    };

    return (
        <section className="py-20 bg-blue-50 dark:bg-slate-800">
            <div className="container mx-auto px-6">
                <div className="max-w-3xl mx-auto text-center">
                    <WaterDropIcon className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">{t('fun_facts_title')}</h2>
                    <div className="relative min-h-[6rem] flex items-center justify-center">
                         <p key={currentFactIndex} className="text-xl text-slate-700 dark:text-slate-300 leading-relaxed animate-fade-in">
                            "{facts[currentFactIndex]}"
                        </p>
                    </div>
                    <button 
                        onClick={showNewFact}
                        className="mt-6 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold py-2 px-6 rounded-full shadow-md hover:shadow-lg hover:bg-slate-100 dark:hover:bg-slate-600 transition-all transform hover:scale-105"
                    >
                        {t('fun_facts_button')}
                    </button>
                </div>
            </div>
        </section>
    );
};

export default FunFacts;