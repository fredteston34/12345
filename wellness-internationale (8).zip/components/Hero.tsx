import React, { useState, useEffect } from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';

const Hero: React.FC = () => {
    const { t } = useTranslations();
    const [isLoaded, setIsLoaded] = useState(false);

    // SVG Gradient Background
    const backgroundUrl = "data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3clinearGradient id='g' x1='0%25' y1='0%25' x2='0%25' y2='100%25'%3e%3cstop offset='0%25' stop-color='%2360a5fa'/%3e%3cstop offset='100%25' stop-color='%231e40af'/%3e%3c/linearGradient%3e%3c/defs%3e%3crect fill='url(%23g)' width='100%25' height='100%25'/%3e%3c/svg%3e";

    useEffect(() => {
        // Simulate loading for text animation
        setIsLoaded(true);
    }, []);

    return (
      <section id="accueil" className="relative h-[80vh] min-h-[500px] flex items-center justify-center text-white bg-slate-900 transition-colors duration-500 overflow-hidden">
        <div 
          className="absolute inset-0 w-full h-full object-cover" 
          style={{ backgroundImage: `url("${backgroundUrl}")` }}
        ></div>
        <div className="absolute inset-0 bg-black opacity-40 z-10 dark:opacity-60"></div>
        <div 
            className="relative z-20 container mx-auto px-6 text-center transition-opacity duration-1000"
            style={{ opacity: isLoaded ? 1 : 0 }}
        >
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4" style={{textShadow: '0 2px 4px rgba(0,0,0,0.5)'}}>
            {t('hero_title')}
          </h1>
          <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8" style={{textShadow: '0 1px 3px rgba(0,0,0,0.5)'}}>
            {t('hero_subtitle')}
          </p>
          <a 
            href="#produits"
            className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full text-lg transition-transform duration-300 transform hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 focus-visible:ring-white"
          >
            {t('hero_cta')}
          </a>
        </div>
      </section>
    );
};

export default Hero;