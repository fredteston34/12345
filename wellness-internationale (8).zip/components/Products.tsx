

import React, { useState, useMemo, lazy, Suspense } from 'react';
import { HomeIcon, OfficeIcon, IndustryIcon, CompareIcon, XIcon, HeartIcon, PrinterIcon, ShareIcon, CubeIcon, SparklesIcon, SpinnerIcon, WarningIcon } from './Icons.tsx';
import ComparisonModal from './ComparisonModal.tsx';
import FavoritesModal from './FavoritesModal.tsx';
import DatasheetModal from './DatasheetModal.tsx';
import ThreeDModal from './ThreeDModal.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { useAppStore } from '../hooks/useAppStore.tsx';
import type { Product } from '../types.ts';
import { getProductData } from '../lib/product-data.ts';

// Lazy load the new modal
const InsightModal = lazy(() => import('./InsightModal.tsx'));

type ProductCardProps = Product & {
    isBestSeller?: boolean;
    onCompareToggle: (productName: string) => void;
    isSelectedForCompare: boolean;
    isCompareDisabled: boolean;
    onFavoriteToggle: (productName: string) => void;
    isFavorite: boolean;
    onDatasheetOpen: () => void;
    onThreeDModalOpen: () => void;
    onGetInsight: () => void; // <-- New prop
};

const ProductCard: React.FC<ProductCardProps> = (props) => {
    const { 
        imageSrc, srcSet, sizes, name, capacity, description, features, icon, isBestSeller,
        onCompareToggle, isSelectedForCompare, isCompareDisabled, onFavoriteToggle, isFavorite, 
        onDatasheetOpen, onThreeDModalOpen, onGetInsight
    } = props;

    const { t } = useTranslations();
    const [shareFeedback, setShareFeedback] = useState('');
    
    const handleShare = async () => {
        const shareData = {
            title: t('share_title'),
            text: t('share_text', name),
            url: window.location.href,
        };
        try {
            if (navigator.share) {
                await navigator.share(shareData);
            } else {
                await navigator.clipboard.writeText(shareData.url);
                setShareFeedback(t('share_success'));
                setTimeout(() => setShareFeedback(''), 2000);
            }
        } catch (err) {
            console.error('Share failed:', err);
            setShareFeedback(t('share_error'));
            setTimeout(() => setShareFeedback(''), 2000);
        }
    };
    
    return (
    <div className={`relative bg-white dark:bg-slate-800 rounded-lg overflow-hidden flex flex-col h-full transition-all duration-300 motion-reduce:transform-none ${
        isBestSeller 
            ? 'shadow-xl hover:shadow-2xl shadow-amber-200/80 dark:shadow-amber-900/50 border border-amber-300 dark:border-amber-600 transform hover:-translate-y-2' 
            : 'shadow-lg hover:shadow-xl dark:shadow-black/20 transform hover:-translate-y-2'
    }`}>
        <div className="absolute top-3 right-3 z-10 flex flex-col gap-2">
            {isBestSeller && (
                <div className="bg-amber-400 text-amber-900 text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full self-end">
                    {t('product_bestseller')}
                </div>
            )}
            <div className="flex gap-2">
                 <button
                    onClick={handleShare}
                    className="p-2 rounded-full bg-white/80 dark:bg-slate-700/80 backdrop-blur-sm text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800"
                    aria-label={t('share_product_aria', name)}
                >
                    <ShareIcon className="w-5 h-5" />
                </button>
                <button
                    onClick={onDatasheetOpen}
                    className="p-2 rounded-full bg-white/80 dark:bg-slate-700/80 backdrop-blur-sm text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800"
                    aria-label={t('product_datasheet_aria', name)}
                >
                    <PrinterIcon className="w-5 h-5" />
                </button>
                <button
                    onClick={() => onFavoriteToggle(name)}
                    aria-pressed={isFavorite}
                    className={`p-2 rounded-full transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800
                        ${isFavorite ? 'text-red-500 bg-red-100 dark:bg-red-900/50 dark:text-red-400' : 'bg-white/80 dark:bg-slate-700/80 backdrop-blur-sm text-slate-700 dark:text-slate-200 hover:bg-red-50 dark:hover:bg-red-900/50'}
                    `}
                    aria-label={isFavorite ? t('product_remove_favorite_aria', name) : t('product_add_favorite_aria', name)}
                >
                    <HeartIcon className={`w-5 h-5 transition-all ${isFavorite ? 'fill-current' : ''}`} />
                </button>
                <button
                    onClick={() => onCompareToggle(name)}
                    disabled={isCompareDisabled && !isSelectedForCompare}
                    aria-pressed={isSelectedForCompare}
                    className={`p-2 rounded-full transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800
                        ${isSelectedForCompare ? 'bg-blue-600 text-white' : 'bg-white/80 dark:bg-slate-700/80 backdrop-blur-sm text-slate-700 dark:text-slate-200 hover:bg-blue-100 dark:hover:bg-blue-900/50'}
                        ${isCompareDisabled && !isSelectedForCompare ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                    aria-label={isSelectedForCompare ? t('product_remove_compare_aria', name) : t('product_add_compare_aria', name)}
                >
                    <CompareIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
        <img src={imageSrc} srcSet={srcSet} sizes={sizes} alt={name} className="w-full h-56 object-cover" loading="lazy" crossOrigin="anonymous" />
        <div className="p-6 flex flex-col flex-grow">
            <div className="flex items-center mb-2">
              {icon}
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 ml-2">{name}</h3>
            </div>
            <p className="text-blue-600 dark:text-blue-400 font-semibold mb-3">{capacity}</p>
            <p className="text-slate-600 dark:text-slate-300 mb-4 flex-grow">{description}</p>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400 mb-6">
                {features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                        <svg className="w-4 h-4 mr-2 text-green-500 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                        {feature}
                    </li>
                ))}
            </ul>
            <div className="mt-auto pt-6 border-t border-slate-200 dark:border-slate-700/60 space-y-4">
                 <div className="min-h-[3rem] flex items-center">
                     <button
                        onClick={onGetInsight}
                        aria-label={t('product_ai_aria_label', name)}
                        className="w-full flex items-center justify-center gap-2 text-sm font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors p-2 rounded-lg bg-blue-50 dark:bg-blue-900/30 hover:bg-blue-100 dark:hover:bg-blue-900/50"
                    >
                        <SparklesIcon className="w-4 h-4" />
                        {t('product_ai_why_button')}
                    </button>
                 </div>

                <div className="flex flex-col sm:flex-row gap-2">
                    <a href="#contact" className="flex-1 bg-slate-800 text-white font-semibold py-2 px-4 rounded-lg text-center hover:bg-slate-900 dark:bg-blue-600 dark:hover:bg-blue-700 transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800 flex items-center justify-center" aria-label={t('product_quote_button_aria', name)}>
                        {t('product_quote_button')}
                    </a>
                    <button
                        onClick={onThreeDModalOpen}
                        className="flex-1 bg-slate-100 text-slate-800 font-semibold py-2 px-4 rounded-lg text-center hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-100 dark:hover:bg-slate-600 transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-800 flex items-center justify-center gap-2"
                        aria-label={t('product_view_3d_ar_aria', name)}
                    >
                        <CubeIcon className="w-5 h-5" />
                        <span>{t('product_view_3d_button')}</span>
                    </button>
                </div>
            </div>
        </div>
        {shareFeedback && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs px-2 py-1 rounded-md animate-fade-in">{shareFeedback}</div>}
    </div>
)};

const Products: React.FC = () => {
    const { t } = useTranslations();
    const { 
        favorites, 
        comparisonList, 
        toggleFavorite, 
        toggleComparison, 
        clearComparison,
        isItemFavorite,
        isItemInComparison 
    } = useAppStore();
    
    const [activeFilter, setActiveFilter] = useState('Tous');
    const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
    const [isFavoritesModalOpen, setIsFavoritesModalOpen] = useState(false);
    const [datasheetProduct, setDatasheetProduct] = useState<Product | null>(null);
    const [threeDProduct, setThreeDProduct] = useState<Product | null>(null);
    const [insightState, setInsightState] = useState<{
        product: Product | null;
        insight: string;
        isLoading: boolean;
        error: string | null;
    }>({ product: null, insight: '', isLoading: false, error: null });
    
    const productDataList: Product[] = useMemo(() => getProductData(t), [t]);
    const BEST_SELLER_NAME = useMemo(() => t('product_home_name'), [t]);

    const handleGetInsight = async (product: Product) => {
        setInsightState({ product, insight: '', isLoading: true, error: null });

        try {
            let context = "";
            const otherComparedItems = comparisonList.filter(item => item !== product.name).join(', ');
            if (otherComparedItems) {
                 context += `The user is comparing it with: ${otherComparedItems}. `;
            }
            if (favorites.length > 0) {
                context += `The user has shown interest in these products: ${favorites.join(', ')}. `;
            }
            if (!context) {
                context = "The user has not provided any other context yet."
            }

            const response = await fetch('/api/product-insight', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    product: { name: product.name, type: product.type, capacity: product.capacity, features: product.features, description: product.description },
                    context
                })
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'API call failed');
            }

            setInsightState(prev => ({ ...prev, insight: result.insight, isLoading: false }));
        } catch (error) {
            console.error("AI Insight Failed:", error);
            setInsightState(prev => ({ ...prev, isLoading: false, error: t('product_ai_error') }));
        }
    };


    const comparisonProducts = productDataList.filter(p => comparisonList.includes(p.name));
    const filteredProducts = activeFilter === t('filter_all') ? productDataList : productDataList.filter(p => p.type === activeFilter);
    const filters = [t('filter_all'), t('filter_home'), t('filter_office'), t('filter_industrial')];

    return (
        <>
            <section id="produits" className="py-20 bg-slate-50 dark:bg-slate-900/50 scroll-mt-20">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-100">{t('products_title')}</h2>
                        <p className="mt-4 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                            {t('products_subtitle')}
                        </p>
                    </div>
                     <div className="flex justify-center flex-wrap gap-4 mb-12">
                          {filters.map(filter => (
                              <button
                                  key={filter}
                                  onClick={() => setActiveFilter(filter)}
                                  className={`px-6 py-2 rounded-full font-semibold transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 dark:focus-visible:ring-offset-slate-900 ${
                                      activeFilter === filter
                                          ? 'bg-blue-600 text-white shadow-md'
                                          : 'bg-white text-slate-600 hover:bg-blue-100 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'
                                  }`}
                              >
                                  {filter}
                              </button>
                          ))}
                      </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredProducts.map((product) => (
                            <div id={`product-${product.id}`} key={product.id} className="transition-opacity duration-500 scroll-mt-24">
                                <ProductCard 
                                {...product} 
                                isBestSeller={product.name === BEST_SELLER_NAME} 
                                onCompareToggle={toggleComparison}
                                isSelectedForCompare={isItemInComparison(product.name)}
                                isCompareDisabled={comparisonList.length >= 3}
                                onFavoriteToggle={toggleFavorite}
                                isFavorite={isItemFavorite(product.name)}
                                onDatasheetOpen={() => setDatasheetProduct(product)}
                                onThreeDModalOpen={() => setThreeDProduct(product)}
                                onGetInsight={() => handleGetInsight(product)}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            </section>
            
            {comparisonList.length > 0 && (
                <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 animate-scale-in">
                    <div className="bg-slate-800/95 backdrop-blur-md text-white rounded-xl shadow-2xl flex items-center gap-4 p-4 dark:bg-slate-700/95">
                        <div className="flex -space-x-4">
                            {comparisonProducts.map(p => (
                                <img key={p.name} src={p.imageSrc} alt={p.name} className="w-12 h-12 rounded-full border-2 border-slate-600 dark:border-slate-500 object-cover"/>
                            ))}
                        </div>
                        <div>
                            <p className="font-bold text-lg">{t('compare_panel_title')}</p>
                            <p className="text-sm text-slate-300">{t('compare_panel_subtitle', comparisonList.length)}</p>
                        </div>
                        <button 
                            onClick={() => setIsCompareModalOpen(true)}
                            disabled={comparisonList.length < 2}
                            className="bg-blue-600 hover:bg-blue-700 font-semibold py-2 px-5 rounded-md transition-colors disabled:bg-slate-500 disabled:cursor-not-allowed"
                        >
                            {t('compare_button')}
                        </button>
                        <button
                            onClick={clearComparison}
                            aria-label={t('compare_clear_aria')}
                            className="bg-slate-600 hover:bg-slate-500 p-2 rounded-full"
                        >
                            <XIcon className="w-5 h-5"/>
                        </button>
                    </div>
                </div>
            )}

            {favorites.length > 0 && (
                <div className="fixed bottom-24 right-8 z-40 animate-scale-in">
                    <button
                        onClick={() => setIsFavoritesModalOpen(true)}
                        className="flex items-center justify-center gap-2 bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-5 rounded-full shadow-lg transition-transform duration-300 transform hover:scale-105"
                        aria-label={t('favorites_view_aria', favorites.length)}
                    >
                        <HeartIcon className="w-6 h-6 fill-current" />
                        <span className="text-lg">{favorites.length}</span>
                    </button>
                </div>
            )}

            {isCompareModalOpen && (
                <ComparisonModal
                    products={comparisonProducts}
                    onClose={() => setIsCompareModalOpen(false)}
                />
            )}

            {isFavoritesModalOpen && (
                <FavoritesModal
                    products={productDataList.filter(p => favorites.includes(p.name))}
                    onClose={() => setIsFavoritesModalOpen(false)}
                    onClear={() => {
                        favorites.forEach(name => toggleFavorite(name));
                        setIsFavoritesModalOpen(false);
                    }}
                    onRemove={toggleFavorite}
                />
            )}
            
            {datasheetProduct && (
                <DatasheetModal 
                    product={datasheetProduct}
                    onClose={() => setDatasheetProduct(null)}
                />
            )}

            {threeDProduct && (
                <ThreeDModal 
                    product={threeDProduct}
                    onClose={() => setThreeDProduct(null)}
                />
            )}

            {insightState.product && (
                 <Suspense>
                    <InsightModal
                        state={{
                            productName: insightState.product.name,
                            insight: insightState.insight,
                            isLoading: insightState.isLoading,
                            error: insightState.error,
                        }}
                        onClose={() => setInsightState({ product: null, insight: '', isLoading: false, error: null })}
                    />
                 </Suspense>
            )}
        </>
    );
};

export default Products;