import React, { useState, useEffect, lazy, Suspense } from 'react';
import { WaterDropIcon, SunIcon, MoonIcon, GlobeAltIcon } from './Icons.tsx';
import { useTheme } from '../hooks/useTheme.tsx';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { useAppStore } from '../hooks/useAppStore.tsx';

const DashboardModal = lazy(() => import('./DashboardModal.tsx'));
const LoginModal = lazy(() => import('./LoginModal.tsx'));


const Header: React.FC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [scrollProgress, setScrollProgress] = useState(0);
    const { theme, toggleTheme } = useTheme();
    const { language, setLanguage, t } = useTranslations();
    const { isLoggedIn } = useAppStore();
    const [isDashboardOpen, setIsDashboardOpen] = useState(false);
    const [isLoginOpen, setIsLoginOpen] = useState(false);


    useEffect(() => {
        const handleScroll = () => {
            const totalScroll = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const currentScroll = window.scrollY;
            const progress = totalScroll > 0 ? (currentScroll / totalScroll) * 100 : 0;
            setScrollProgress(progress);
            setIsScrolled(window.scrollY > 10);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { href: '#accueil', text: t('nav_home') },
        { href: '#fonctionnement', text: t('nav_how_it_works') },
        { href: '#produits', text: t('nav_products') },
        { href: '#avantages', text: t('nav_benefits') },
        { href: '#calculateur', text: t('nav_calculator') },
        { href: '#gallery', text: t('nav_gallery') },
        { href: '#videos', text: t('nav_videos') },
        { href: '#temoignages', text: t('nav_testimonials') },
        { href: '#faq', text: t('nav_faq') },
        { href: '#blog', text: t('nav_blog') },
        { href: '#contact', text: t('nav_contact') },
    ];

    return (
        <>
            <header className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg shadow-md dark:shadow-slate-800' : 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg'}`}>
                <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                    <a href="#accueil" className="flex items-center space-x-2 rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900">
                        <WaterDropIcon className="w-8 h-8 text-blue-600 dark:text-blue-500" />
                        <span className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
                            Wellness Internationale
                        </span>
                    </a>

                    <nav className="hidden lg:flex items-center space-x-4">
                        {navLinks.map((link) => (
                            <a key={link.href} href={link.href} className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 rounded-lg transition-colors duration-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none focus-visible:bg-slate-100 dark:focus-visible:bg-slate-800 focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900">
                                {link.text}
                            </a>
                        ))}
                    </nav>
                    
                    <div className="flex items-center gap-4">
                         <div className="hidden lg:flex items-center gap-4">
                            {isLoggedIn ? (
                                <button onClick={() => setIsDashboardOpen(true)} className="text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-full transition-colors">{t('nav_account')}</button>
                            ) : (
                                <button onClick={() => setIsLoginOpen(true)} className="text-sm font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 px-4 py-2 rounded-full transition-colors">{t('nav_login')}</button>
                            )}
                            <button
                                onClick={toggleTheme}
                                aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
                                className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 p-2 rounded-full transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900"
                            >
                                {theme === 'light' ? <MoonIcon className="w-5 h-5" /> : <SunIcon className="w-5 h-5" />}
                            </button>
                            
                            <div className="relative">
                                <GlobeAltIcon className="w-5 h-5 text-slate-600 dark:text-slate-300 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"/>
                                <select
                                    value={language}
                                    onChange={(e) => setLanguage(e.target.value as 'fr' | 'en')}
                                    aria-label="Select language"
                                    className="pl-9 pr-4 py-1.5 text-sm font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-transparent rounded-full appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="fr">FR</option>
                                    <option value="en">EN</option>
                                </select>
                            </div>
                        </div>

                        <div className="lg:hidden">
                            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-slate-800 dark:text-slate-200 focus:outline-none rounded-md focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900">
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                
                {isMenuOpen && (
                    <div className="lg:hidden bg-white dark:bg-slate-900">
                        <nav className="flex flex-col items-center space-y-2 py-4 border-t border-slate-200 dark:border-slate-800">
                            {navLinks.map((link) => (
                                <a key={link.href} href={link.href} onClick={() => setIsMenuOpen(false)} className="block w-full text-center px-6 py-3 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-300 font-medium rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">
                                    {link.text}
                                </a>
                            ))}
                             <div className="flex items-center gap-4 pt-4 border-t border-slate-200 dark:border-slate-800 w-full justify-center mt-3">
                                {isLoggedIn ? (
                                    <button onClick={() => { setIsDashboardOpen(true); setIsMenuOpen(false); }} className="text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-full transition-colors">{t('nav_account')}</button>
                                ) : (
                                    <button onClick={() => { setIsLoginOpen(true); setIsMenuOpen(false); }} className="text-sm font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 px-4 py-2 rounded-full transition-colors">{t('nav_login')}</button>
                                )}
                                <button
                                    onClick={toggleTheme}
                                    aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
                                    className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 p-2 rounded-full transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                                >
                                    {theme === 'light' ? <MoonIcon className="w-6 h-6" /> : <SunIcon className="w-6 h-6" />}
                                </button>
                                
                                <div className="relative">
                                    <GlobeAltIcon className="w-5 h-5 text-slate-600 dark:text-slate-300 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"/>
                                    <select
                                        value={language}
                                        onChange={(e) => setLanguage(e.target.value as 'fr' | 'en')}
                                        aria-label="Select language"
                                        className="pl-9 pr-4 py-1.5 text-sm font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-transparent rounded-full appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    >
                                        <option value="fr">Français</option>
                                        <option value="en">English</option>
                                    </select>
                                </div>
                            </div>
                        </nav>
                    </div>
                )}
                <div className="absolute bottom-0 left-0 h-1 bg-blue-600 dark:bg-blue-500 transition-all duration-150" style={{ width: `${scrollProgress}%` }}></div>
            </header>
            <Suspense>
                {isDashboardOpen && <DashboardModal onClose={() => setIsDashboardOpen(false)} />}
                {isLoginOpen && <LoginModal onClose={() => setIsLoginOpen(false)} />}
            </Suspense>
        </>
    );
};

export default Header;