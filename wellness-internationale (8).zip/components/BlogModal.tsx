
import React from 'react';
import { useTranslations } from '../hooks/useTranslations.tsx';
import { XIcon, CalendarIcon } from './Icons.tsx';
import type { BlogPost } from '../lib/blog-posts.ts';
import Modal from './Modal.tsx';

type BlogModalProps = {
    post: BlogPost;
    onClose: () => void;
};

const BlogModal: React.FC<BlogModalProps> = ({ post, onClose }) => {
    const { t } = useTranslations();
    
    return (
        <Modal onClose={onClose} panelClassName="max-w-4xl">
            <header className="flex-shrink-0 flex justify-end items-center p-4">
                <button onClick={onClose} aria-label={t('blog_modal_close_aria')} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-full p-1 z-10">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="overflow-y-auto flex-grow -mt-14">
                <img src={post.imageUrl} alt={post.title} className="w-full h-80 object-cover rounded-t-xl" crossOrigin="anonymous"/>
                <div className="p-8 md:p-12">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-slate-100 mb-3">{post.title}</h2>
                    <p className="flex items-center text-md text-slate-500 dark:text-slate-400 mb-6">
                        <CalendarIcon className="w-5 h-5 mr-2" />
                        {post.date}
                    </p>
                    <div className="text-slate-700 dark:text-slate-300 leading-relaxed space-y-4 text-lg">
                        {post.content.split('\n').map((paragraph, index) => (
                            <p key={index}>{paragraph}</p>
                        ))}
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default BlogModal;
