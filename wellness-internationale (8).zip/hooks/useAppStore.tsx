import { create } from 'zustand';

type AppState = {
    favorites: string[];
    comparisonList: string[];
    toggleFavorite: (productName: string) => void;
    toggleComparison: (productName: string) => void;
    clearComparison: () => void;
    isItemFavorite: (productName: string) => boolean;
    isItemInComparison: (productName: string) => boolean;
    isLoggedIn: boolean;
    userProductId: string | null;
    login: () => void;
    logout: () => void;
};

export const useAppStore = create<AppState>((set, get) => ({
    // State
    favorites: [],
    comparisonList: [],
    isLoggedIn: false,
    userProductId: null,

    // Actions
    toggleFavorite: (productName: string) => set(state => ({
        favorites: state.favorites.includes(productName)
            ? state.favorites.filter(name => name !== productName)
            : [...state.favorites, productName]
    })),

    toggleComparison: (productName: string) => set(state => {
        if (state.comparisonList.includes(productName)) {
            return { comparisonList: state.comparisonList.filter(name => name !== productName) };
        }
        if (state.comparisonList.length < 3) {
            return { comparisonList: [...state.comparisonList, productName] };
        }
        return state; // No change if limit is reached
    }),

    clearComparison: () => set({ comparisonList: [] }),

    login: () => set({ isLoggedIn: true, userProductId: 'home20' }),

    logout: () => set({ isLoggedIn: false, userProductId: null }),

    // Selectors (as functions, to maintain API compatibility with components)
    isItemFavorite: (productName: string) => get().favorites.includes(productName),
    isItemInComparison: (productName: string) => get().comparisonList.includes(productName),
}));