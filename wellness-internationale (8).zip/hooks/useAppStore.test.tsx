import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useAppStore } from './useAppStore.tsx';

describe('useAppStore', () => {
    
    // Reset store to its initial state before each test to ensure isolation
    beforeEach(() => {
        act(() => {
            useAppStore.setState({
                favorites: [],
                comparisonList: [],
                isLoggedIn: false,
                userProductId: null,
            });
        });
    });

    it('should have correct initial state', () => {
        const { result } = renderHook(() => useAppStore());
        
        expect(result.current.favorites).toEqual([]);
        expect(result.current.comparisonList).toEqual([]);
        expect(result.current.isLoggedIn).toBe(false);
        expect(result.current.userProductId).toBeNull();
    });

    it('should toggle a favorite on and off', () => {
        const { result } = renderHook(() => useAppStore());
        
        act(() => {
            result.current.toggleFavorite('product-1');
        });
        
        expect(result.current.favorites).toContain('product-1');
        expect(result.current.isItemFavorite('product-1')).toBe(true);

        act(() => {
            result.current.toggleFavorite('product-1');
        });

        expect(result.current.favorites).not.toContain('product-1');
        expect(result.current.isItemFavorite('product-1')).toBe(false);
    });

    it('should toggle a comparison item on and off', () => {
        const { result } = renderHook(() => useAppStore());
        
        act(() => {
            result.current.toggleComparison('product-1');
        });

        expect(result.current.comparisonList).toContain('product-1');
        expect(result.current.isItemInComparison('product-1')).toBe(true);

        act(() => {
            result.current.toggleComparison('product-1');
        });
        
        expect(result.current.comparisonList).not.toContain('product-1');
        expect(result.current.isItemInComparison('product-1')).toBe(false);
    });
    
    it('should not allow more than 3 items in the comparison list', () => {
        const { result } = renderHook(() => useAppStore());

        act(() => {
            result.current.toggleComparison('product-1');
            result.current.toggleComparison('product-2');
            result.current.toggleComparison('product-3');
        });

        expect(result.current.comparisonList).toHaveLength(3);

        // Attempt to add a fourth item
        act(() => {
            result.current.toggleComparison('product-4');
        });

        expect(result.current.comparisonList).toHaveLength(3);
        expect(result.current.comparisonList).not.toContain('product-4');
    });

    it('should clear the comparison list', () => {
        const { result } = renderHook(() => useAppStore());

        act(() => {
            result.current.toggleComparison('product-1');
            result.current.toggleComparison('product-2');
        });

        expect(result.current.comparisonList).toHaveLength(2);

        act(() => {
            result.current.clearComparison();
        });

        expect(result.current.comparisonList).toHaveLength(0);
    });

    it('should handle user login and logout', () => {
        const { result } = renderHook(() => useAppStore());

        act(() => {
            result.current.login();
        });

        expect(result.current.isLoggedIn).toBe(true);
        expect(result.current.userProductId).toBe('home20');

        act(() => {
            result.current.logout();
        });

        expect(result.current.isLoggedIn).toBe(false);
        expect(result.current.userProductId).toBeNull();
    });
});